/* Chepe Delivery - utilidades compartidas */
(function () {
  'use strict';
  const CD = (window.CD = {});
  CD.TZ = 'America/Managua';
  CD.sb = null;
  CD.cfg = null;
  CD.profile = null;

  // ---------- Utilidades básicas ----------
  CD.esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g,
    (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  CD.$ = (sel, root) => (root || document).querySelector(sel);
  CD.$$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));
  CD.sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  CD.debounce = (fn, ms) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };

  CD.plainMoney = (n) => Number(n || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  CD.money = (n) => 'C$' + CD.plainMoney(n);

  // ---------- Fechas (siempre en hora de Nicaragua) ----------
  CD.fmtDate = (iso) => iso ? new Intl.DateTimeFormat('en-GB', { timeZone: CD.TZ, day: '2-digit', month: '2-digit', year: 'numeric' }).format(new Date(iso)) : '—';
  CD.fmtTime = (iso) => iso ? new Intl.DateTimeFormat('en-US', { timeZone: CD.TZ, hour: 'numeric', minute: '2-digit', hour12: true }).format(new Date(iso)) : '';
  CD.fmtDT = (iso) => iso ? CD.fmtDate(iso) + ' ' + CD.fmtTime(iso) : '—';
  CD.todayISO = () => new Intl.DateTimeFormat('en-CA', { timeZone: CD.TZ, year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date());
  CD.nowHHMM = () => new Intl.DateTimeFormat('en-GB', { timeZone: CD.TZ, hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).format(new Date());
  // Nicaragua no usa horario de verano: siempre UTC-06:00
  CD.toManaguaISO = (dateStr, timeStr) => `${dateStr}T${timeStr || '00:00'}:00-06:00`;

  // ---------- Teléfonos (Nicaragua: 8 dígitos => +505) ----------
  CD.normalizePhone = (p) => {
    const d = String(p || '').replace(/\D/g, '');
    if (d.length === 8) return '505' + d;
    if (d.length === 11 && d.startsWith('505')) return d;
    if (d.length === 13 && d.startsWith('00505')) return d.slice(2);
    return d;
  };
  CD.phoneOk = (p) => { const n = CD.normalizePhone(p).length; return n >= 8 && n <= 15; };
  CD.waLink = (phone, text) => `https://wa.me/${CD.normalizePhone(phone)}?text=${encodeURIComponent(text)}`;
  CD.mapsLink = (address) => `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(address)}`;

  // ---------- Errores ----------
  const ERR = {
    no_autorizado: 'No tienes permiso para realizar esta acción.',
    factura_no_encontrada: 'No se encontró la factura.',
    ya_completada: 'Esta factura ya fue completada.',
    ya_enviada: 'Esta factura ya estaba marcada como enviada.',
    estado_invalido: 'La factura no está en un estado que permita esta acción.',
    monto_invalido: 'Escribe un monto válido (0 o mayor).',
    monto_no_permitido: 'No se puede poner monto gastado en una factura pendiente.',
    costo_invalido: 'El costo del delivery no es válido.',
    telefono_invalido: 'El número de teléfono no es válido.',
    cliente_invalido: 'Escribe el nombre del cliente.',
    direccion_invalida: 'Escribe la dirección de entrega.',
    motorizado_invalido: 'Selecciona un motorizado activo.',
    motivo_requerido: 'Escribe el motivo (mínimo 3 letras).',
    'Invalid login credentials': 'Usuario o contraseña incorrectos.',
    'User is banned': 'Tu cuenta está desactivada. Contacta al administrador.',
  };
  CD.isNetErr = (e) => /failed to fetch|networkerror|load failed|network request failed|fetch/i.test((e && e.message) || '');
  CD.errMsg = (e) => {
    const m = (e && e.message) || String(e || '');
    for (const k in ERR) if (m.includes(k)) return ERR[k];
    if (CD.isNetErr(e)) return 'Sin conexión con el servidor. Revisa tu Internet e inténtalo de nuevo.';
    return 'Ocurrió un error: ' + m;
  };

  // RPC con reintentos controlados SOLO ante fallos de red
  // (las funciones del servidor son idempotentes o rechazan repeticiones).
  CD.rpc = async (name, args, opts) => {
    const retries = (opts && opts.retries != null) ? opts.retries : 2;
    let lastErr;
    for (let i = 0; i <= retries; i++) {
      try {
        const { data, error } = await CD.sb.rpc(name, args || {});
        if (error) throw error;
        return data;
      } catch (e) {
        lastErr = e;
        if (CD.isNetErr(e) && i < retries) { await CD.sleep(900 * (i + 1)); continue; }
        throw e;
      }
    }
    throw lastErr;
  };

  // Consulta de lectura con 1 reintento por red
  CD.q = async (builderFn) => {
    for (let i = 0; i < 2; i++) {
      try {
        const res = await builderFn();
        if (res.error) throw res.error;
        return res;
      } catch (e) {
        if (CD.isNetErr(e) && i === 0) { await CD.sleep(900); continue; }
        throw e;
      }
    }
  };

  // ---------- Interfaz ----------
  CD.toast = (msg, type, ms) => {
    const box = document.getElementById('toasts');
    const el = document.createElement('div');
    el.className = 'toast ' + (type || '');
    el.textContent = msg;
    box.appendChild(el);
    setTimeout(() => el.remove(), ms || 4500);
  };
  CD.ok = (m) => CD.toast(m, 'ok');
  CD.fail = (e) => CD.toast(typeof e === 'string' ? e : CD.errMsg(e), 'err', 6500);

  CD.withBusy = async (btn, fn) => {
    if (!btn || btn.disabled) return;
    btn.disabled = true; btn.classList.add('loading');
    try { return await fn(); }
    finally { btn.disabled = false; btn.classList.remove('loading'); }
  };

  // Hoja modal (se apila si hay varias)
  CD.sheet = (title, html) => {
    const ov = document.createElement('div');
    ov.className = 'overlay';
    ov.innerHTML = `<div class="sheet" role="dialog" aria-modal="true">
      <div class="sheet-head"><h3></h3><button class="icon-btn" aria-label="Cerrar" type="button">✕</button></div>
      <div class="sheet-body"></div></div>`;
    ov.querySelector('h3').textContent = title || '';
    const body = ov.querySelector('.sheet-body');
    body.innerHTML = html || '';
    document.body.appendChild(ov);
    document.body.classList.add('no-scroll');
    let closed = false;
    const api = {
      el: ov, body,
      setTitle: (t) => { ov.querySelector('h3').textContent = t; },
      close: () => {
        if (closed) return; closed = true;
        document.removeEventListener('keydown', onKey);
        ov.remove();
        if (!document.querySelector('.overlay')) document.body.classList.remove('no-scroll');
        if (api.onClose) api.onClose();
      },
    };
    const onKey = (e) => { if (e.key === 'Escape') api.close(); };
    document.addEventListener('keydown', onKey);
    ov.querySelector('.sheet-head button').addEventListener('click', api.close);
    ov.addEventListener('click', (e) => { if (e.target === ov) api.close(); });
    return api;
  };

  CD.confirm = (message, opts) => new Promise((resolve) => {
    const o = opts || {};
    const sh = CD.sheet(o.title || 'Confirmar', `
      <p class="pre">${CD.esc(message)}</p>
      <div class="actions">
        <button class="btn ghost" data-no type="button">Cancelar</button>
        <button class="btn ${o.danger ? 'danger' : 'primary'}" data-yes type="button">${CD.esc(o.okText || 'Confirmar')}</button>
      </div>`);
    let done = false;
    const finish = (v) => { if (done) return; done = true; sh.close(); resolve(v); };
    sh.onClose = () => finish(false);
    sh.body.querySelector('[data-no]').addEventListener('click', () => finish(false));
    sh.body.querySelector('[data-yes]').addEventListener('click', () => finish(true));
  });

  // Canal Realtime que se apaga cuando la pantalla está oculta (ahorra recursos)
  CD.live = (name, specs, onEvent) => {
    let ch = null;
    const open = () => {
      if (ch) return;
      ch = CD.sb.channel(name);
      specs.forEach((s) => ch.on('postgres_changes', s, onEvent));
      ch.subscribe();
    };
    const shut = () => { if (ch) { CD.sb.removeChannel(ch); ch = null; } };
    const onVis = () => {
      if (document.hidden) shut();
      else { open(); onEvent({ resumed: true }); }
    };
    document.addEventListener('visibilitychange', onVis);
    open();
    return { stop: () => { shut(); document.removeEventListener('visibilitychange', onVis); } };
  };

  CD.statusLabel = (s) => ({ pending: 'Pendiente', completed: 'Completada', sent: 'Enviada', cancelled: 'Anulada' }[s] || s);
  CD.badge = (s) => `<span class="badge ${CD.esc(s)}">${CD.esc(CD.statusLabel(s))}</span>`;

  CD.parseAmount = (txt) => {
    const t = String(txt == null ? '' : txt).trim().replace(/,/g, '.').replace(/^C\$\s*/i, '');
    if (!/^\d+(\.\d{1,2})?$/.test(t)) return null;
    const n = Number(t);
    return n >= 0 && n <= 99999999 ? n : null;
  };

  // Cambiar mi contraseña (admin o motorizado)
  CD.changePasswordSheet = () => {
    const sh = CD.sheet('Cambiar mi contraseña', `
      <div class="field"><label>Nueva contraseña</label><input type="password" id="np1" autocomplete="new-password" minlength="8"></div>
      <div class="field"><label>Repite la contraseña</label><input type="password" id="np2" autocomplete="new-password"></div>
      <button class="btn primary block" id="npGo" type="button">Guardar contraseña</button>`);
    const go = sh.body.querySelector('#npGo');
    go.addEventListener('click', () => CD.withBusy(go, async () => {
      const a = sh.body.querySelector('#np1').value, b = sh.body.querySelector('#np2').value;
      if (a.length < 8) return CD.fail('La contraseña debe tener al menos 8 caracteres.');
      if (a !== b) return CD.fail('Las contraseñas no coinciden.');
      const { error } = await CD.sb.auth.updateUser({ password: a });
      if (error) return CD.fail(error.message);
      CD.ok('Contraseña actualizada.');
      sh.close();
    }));
  };

  CD.randomPassword = (len) => {
    const chars = 'abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    const arr = new Uint32Array(len || 10);
    crypto.getRandomValues(arr);
    return Array.from(arr, (n) => chars[n % chars.length]).join('');
  };
})();
