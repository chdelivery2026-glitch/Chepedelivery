/* Panel del administrador */
(function () {
  'use strict';
  const { esc, $, $$, money } = CD;

  const DEFAULT_TPL = 'Hola, {cliente}. 👋\nTe compartimos tu factura de {negocio}.\n\n🧾 Factura: {factura}\n📅 Fecha: {fecha}\n🛍️ Monto de tu pedido: C${monto}\n🛵 Costo del delivery: C${delivery}\n💰 TOTAL A PAGAR: C${total}\n\nGracias por preferir {negocio}.';

  const NAV = [
    { id: 'dashboard', label: 'Panel', icon: '📊' },
    { id: 'new', label: 'Nueva factura', icon: '➕' },
    { id: 'invoices', label: 'Facturas / Historial', icon: '🧾' },
    { id: 'motorists', label: 'Motorizados', icon: '🛵' },
    { id: 'customers', label: 'Clientes', icon: '👥' },
    { id: 'settings', label: 'Configuración', icon: '⚙️' },
  ];

  CD.admin = {
    mount(root, profile) {
      const state = {
        view: 'dashboard', seq: 0, settings: {}, motorists: [],
        period: 'day', hist: { q: '', status: '', motorist: '', from: '', to: '', page: 0 },
        newReqId: null, live: null, unread: 0,
      };
      const PAGE = 20;

      root.innerHTML = `
        <header class="topbar">
          <button class="icon-btn" id="aMenu" aria-label="Abrir menú" type="button">☰</button>
          <div class="brand">🛵 Chepe <span>Delivery</span></div>
          <button class="icon-btn" id="aBell" aria-label="Notificaciones" type="button">🔔<span class="dot" id="aDot" hidden>0</span></button>
        </header>
        <div class="drawer-overlay" id="aOv" hidden></div>
        <nav class="drawer" id="aDrawer">
          <div class="who"><b>${esc(profile.full_name)}</b><br><span class="muted small">Administrador</span></div>
          ${NAV.map((n) => `<button class="nav" data-go="${n.id}" type="button"><span>${n.icon}</span><span>${n.label}</span></button>`).join('')}
          <div class="spacer"></div>
          <button class="nav" id="aPass" type="button"><span>🔑</span><span>Cambiar contraseña</span></button>
          <button class="nav" id="aOut" type="button"><span>⎋</span><span>Cerrar sesión</span></button>
        </nav>
        <main class="view" id="aView"></main>`;

      const view = $('#aView', root);
      const drawer = $('#aDrawer', root);
      const ov = $('#aOv', root);
      const openMenu = () => { drawer.classList.add('open'); ov.hidden = false; };
      const closeMenu = () => { drawer.classList.remove('open'); ov.hidden = true; };
      $('#aMenu', root).addEventListener('click', openMenu);
      ov.addEventListener('click', closeMenu);
      $('#aOut', root).addEventListener('click', () => CD.logout());
      $('#aPass', root).addEventListener('click', () => { closeMenu(); CD.changePasswordSheet(); });
      $('#aBell', root).addEventListener('click', openNotifications);
      drawer.addEventListener('click', (e) => {
        const b = e.target.closest('[data-go]'); if (!b) return;
        closeMenu(); go(b.dataset.go);
      });

      function go(v, params) {
        state.view = v;
        $$('.nav[data-go]', root).forEach((b) => b.classList.toggle('active', b.dataset.go === v));
        window.scrollTo(0, 0);
        if (params && params.hist) Object.assign(state.hist, params.hist, { page: 0 });
        render();
      }
      function render() {
        const my = ++state.seq;
        view.onclick = null;
        view.innerHTML = '<div class="loading-box"><div class="spinner big"></div></div>';
        const fn = { dashboard: vDashboard, new: vNew, invoices: vInvoices, motorists: vMotorists, customers: vCustomers, settings: vSettings }[state.view];
        fn(my).catch((e) => { if (my === state.seq) view.innerHTML = `<div class="error-box">${esc(CD.errMsg(e))}</div><button class="btn block" id="retry" type="button">Reintentar</button>`, $('#retry', view).addEventListener('click', render); });
      }
      const stale = (my) => my !== state.seq;

      // ---------- Datos auxiliares ----------
      async function loadSettings() {
        const { data } = await CD.q(() => CD.sb.from('settings').select('key,value'));
        state.settings = {};
        (data || []).forEach((r) => { state.settings[r.key] = r.value; });
      }
      async function loadMotorists(onlyActive) {
        const { data } = await CD.q(() => {
          let q = CD.sb.from('profiles').select('id,full_name,username,active').eq('role', 'motorizado').order('full_name');
          if (onlyActive) q = q.eq('active', true);
          return q;
        });
        return data || [];
      }
      const fillTemplate = (inv) => {
        const tpl = state.settings.whatsapp_template || DEFAULT_TPL;
        const map = {
          '{cliente}': inv.customer_name, '{negocio}': state.settings.business_name || 'Chepe Delivery',
          '{factura}': inv.invoice_number, '{fecha}': CD.fmtDate(inv.completed_at || inv.created_at),
          '{monto}': CD.plainMoney(inv.amount_spent), '{delivery}': CD.plainMoney(inv.delivery_fee), '{total}': CD.plainMoney(inv.total),
        };
        return Object.keys(map).reduce((t, k) => t.split(k).join(map[k]), tpl);
      };

      // ---------- DASHBOARD ----------
      async function vDashboard(my) {
        const [s, due] = await Promise.all([
          CD.rpc('dashboard_stats', { p_period: state.period }),
          CD.rpc('search_invoices', { p_status: 'completed', p_limit: 10, p_offset: 0 }),
        ]);
        if (stale(my)) return;
        const lbl = { day: 'hoy', week: 'esta semana', month: 'este mes' }[state.period];
        view.innerHTML = `
          <h2>Panel</h2>
          <div class="seg" id="per">
            <button data-p="day" class="${state.period === 'day' ? 'active' : ''}" type="button">Hoy</button>
            <button data-p="week" class="${state.period === 'week' ? 'active' : ''}" type="button">Semana</button>
            <button data-p="month" class="${state.period === 'month' ? 'active' : ''}" type="button">Mes</button>
          </div>
          <div class="grid">
            <div class="tile brand wide"><div class="lbl">Ingresos por delivery (${lbl})</div><div class="val">${money(s.delivery_income)}</div></div>
            <div class="tile wide"><div class="lbl">Total bruto facturado (${lbl})</div><div class="val">${money(s.gross_total)}</div></div>
            <div class="tile"><div class="lbl">Facturas creadas (${lbl})</div><div class="val">${s.invoices_in_period}</div></div>
            <div class="tile click" data-f="pending"><div class="lbl">Pendientes</div><div class="val">${s.pending}</div></div>
            <div class="tile click" data-f="completed"><div class="lbl">Completadas por enviar</div><div class="val">${s.awaiting_send}</div></div>
            <div class="tile click" data-f="sent"><div class="lbl">Enviadas (${lbl})</div><div class="val">${s.sent}</div></div>
            <div class="tile"><div class="lbl">Clientes</div><div class="val">${s.customers}</div></div>
            <div class="tile"><div class="lbl">Motorizados activos</div><div class="val">${s.active_motorists}</div></div>
          </div>
          <div class="info-box"><b>Cómo se calcula:</b> los ingresos cuentan facturas <i>completadas</i> y <i>enviadas</i> según su fecha de finalización. Ingresos por delivery = suma del costo de delivery. Total bruto = monto gastado + delivery. Las anuladas no cuentan.</div>
          <div class="row between mb"><h3 style="margin:0">Por revisar y enviar</h3><button class="btn sm primary" id="newInv" type="button">➕ Nueva</button></div>
          <div id="due">${due.rows.length ? due.rows.map(invRow).join('') : '<div class="empty">No hay facturas esperando envío.</div>'}</div>`;
        $('#per', view).addEventListener('click', (e) => {
          const b = e.target.closest('[data-p]'); if (!b) return; state.period = b.dataset.p; render();
        });
        $$('.tile[data-f]', view).forEach((t) => t.addEventListener('click', () => go('invoices', { hist: { q: '', motorist: '', from: '', to: '', status: t.dataset.f } })));
        $('#newInv', view).addEventListener('click', () => go('new'));
        bindInvRows(view);
      }

      function invRow(r) {
        return `<div class="card click" data-open="${esc(r.id)}">
          <div class="inv-top"><span class="inv-num">${esc(r.invoice_number)}</span>${CD.badge(r.status)}</div>
          <div class="inv-name">${esc(r.customer_name)}</div>
          <div class="inv-line">🛵 ${esc(r.motorist_name)} · ${esc(CD.fmtDT(r.created_at))}</div>
          <div class="row between mt"><span class="muted small">Gastado ${r.amount_spent == null ? '—' : money(r.amount_spent)} · Delivery ${money(r.delivery_fee)}</span>
            <b class="inv-fee">${r.total == null ? '—' : money(r.total)}</b></div></div>`;
      }
      function bindInvRows(scope) {
        $$('[data-open]', scope).forEach((el) => el.addEventListener('click', () => showInvoice(el.dataset.open)));
      }

      // ---------- NUEVA FACTURA ----------
      async function vNew(my) {
        const [mots] = await Promise.all([loadMotorists(true), loadSettings()]);
        if (stale(my)) return;
        if (!state.newReqId) state.newReqId = crypto.randomUUID();
        const fee = state.settings.default_delivery_fee != null ? state.settings.default_delivery_fee : 50;
        view.innerHTML = `
          <h2>Nueva factura / asignar pedido</h2>
          ${mots.length ? '' : '<div class="error-box">No hay motorizados activos. Crea uno primero en «Motorizados».</div>'}
          <form id="f" novalidate>
            <div class="field"><label>Teléfono del cliente</label><input id="phone" inputmode="tel" autocomplete="off" placeholder="8888 8888"><div class="hint" id="phoneHint">Se agrega +505 automáticamente si son 8 dígitos.</div></div>
            <div class="field"><label>Nombre del cliente</label><input id="cname" autocomplete="off" maxlength="120"></div>
            <div class="field"><label>Dirección de entrega</label><textarea id="addr" maxlength="300"></textarea></div>
            <div class="field-row">
              <div class="field"><label>Fecha</label><input type="date" id="date" value="${CD.todayISO()}"></div>
              <div class="field"><label>Hora</label><input type="time" id="time" value="${CD.nowHHMM()}"></div>
            </div>
            <div class="field"><label>Costo del delivery (C$)</label><input id="fee" inputmode="decimal" value="${esc(fee)}"></div>
            <div class="field"><label>Motorizado</label>
              <select id="mot"><option value="">Selecciona…</option>${mots.map((m) => `<option value="${esc(m.id)}">${esc(m.full_name)}</option>`).join('')}</select></div>
            <button class="btn primary block" id="sub" type="submit" ${mots.length ? '' : 'disabled'}>Asignar factura</button>
          </form>`;
        const phone = $('#phone', view);
        // Autocompletar cliente existente por teléfono
        phone.addEventListener('blur', async () => {
          if (!CD.phoneOk(phone.value)) return;
          try {
            const { data } = await CD.sb.from('customers').select('name,address').eq('phone_norm', CD.normalizePhone(phone.value)).maybeSingle();
            if (data) {
              if (!$('#cname', view).value) $('#cname', view).value = data.name;
              if (!$('#addr', view).value && data.address) $('#addr', view).value = data.address;
              $('#phoneHint', view).textContent = '✔ Cliente existente: ' + data.name;
            } else $('#phoneHint', view).textContent = 'Cliente nuevo.';
          } catch (e) { /* sin autocompletar */ }
        });
        $('#f', view).addEventListener('submit', (e) => {
          e.preventDefault();
          CD.withBusy($('#sub', view), async () => {
            const name = $('#cname', view).value.trim(), addr = $('#addr', view).value.trim();
            const feeV = CD.parseAmount($('#fee', view).value), motId = $('#mot', view).value;
            if (!CD.phoneOk(phone.value)) return CD.fail('Escribe un teléfono válido.');
            if (!name) return CD.fail('Escribe el nombre del cliente.');
            if (!addr) return CD.fail('Escribe la dirección de entrega.');
            if (!$('#date', view).value || !$('#time', view).value) return CD.fail('Indica la fecha y la hora.');
            if (feeV === null) return CD.fail('El costo del delivery no es válido.');
            if (!motId) return CD.fail('Selecciona un motorizado.');
            const mname = $('#mot', view).selectedOptions[0].textContent;
            const ok = await CD.confirm(`Cliente: ${name}\nTeléfono: ${phone.value}\nDelivery: ${money(feeV)}\nMotorizado: ${mname}`, { title: '¿Asignar factura?', okText: 'Asignar' });
            if (!ok) return;
            try {
              const inv = await CD.rpc('create_invoice', {
                p_request_id: state.newReqId, p_customer_name: name, p_phone: phone.value.trim(), p_address: addr,
                p_delivery_fee: feeV, p_motorist_id: motId,
                p_scheduled_for: CD.toManaguaISO($('#date', view).value, $('#time', view).value),
              });
              state.newReqId = null; // la siguiente factura usa un identificador nuevo
              CD.ok(`Factura ${inv.invoice_number} asignada a ${mname}.`);
              go('new');
            } catch (err) { CD.fail(err); } // newReqId se conserva: reintentar no duplica
          });
        });
      }

      // ---------- HISTORIAL ----------
      async function vInvoices(my) {
        const mots = await loadMotorists(false);
        if (stale(my)) return;
        const h = state.hist;
        view.innerHTML = `
          <h2>Facturas / Historial</h2>
          <form id="flt" class="card" novalidate>
            <div class="field"><label>Buscar (factura, cliente o teléfono)</label><input id="q" value="${esc(h.q)}" autocomplete="off"></div>
            <div class="field-row">
              <div class="field"><label>Estado</label><select id="st">
                ${[['', 'Todos'], ['pending', 'Pendiente'], ['completed', 'Completada'], ['sent', 'Enviada'], ['cancelled', 'Anulada']].map(([v, l]) => `<option value="${v}" ${h.status === v ? 'selected' : ''}>${l}</option>`).join('')}</select></div>
              <div class="field"><label>Motorizado</label><select id="mo"><option value="">Todos</option>
                ${mots.map((m) => `<option value="${esc(m.id)}" ${h.motorist === m.id ? 'selected' : ''}>${esc(m.full_name)}</option>`).join('')}</select></div>
            </div>
            <div class="field-row">
              <div class="field"><label>Desde</label><input type="date" id="fr" value="${esc(h.from)}"></div>
              <div class="field"><label>Hasta</label><input type="date" id="to" value="${esc(h.to)}"></div>
            </div>
            <div class="row"><button class="btn primary grow" type="submit">Buscar</button><button class="btn ghost" id="clr" type="button">Limpiar</button></div>
          </form>
          <div id="res"><div class="loading-box"><div class="spinner"></div></div></div>`;
        $('#flt', view).addEventListener('submit', (e) => {
          e.preventDefault();
          Object.assign(state.hist, { q: $('#q', view).value.trim(), status: $('#st', view).value, motorist: $('#mo', view).value, from: $('#fr', view).value, to: $('#to', view).value, page: 0 });
          loadResults(my);
        });
        $('#clr', view).addEventListener('click', () => { Object.assign(state.hist, { q: '', status: '', motorist: '', from: '', to: '', page: 0 }); render(); });
        await loadResults(my);
      }
      async function loadResults(my) {
        const h = state.hist, box = $('#res', view);
        box.innerHTML = '<div class="loading-box"><div class="spinner"></div></div>';
        try {
          const r = await CD.rpc('search_invoices', {
            p_q: h.q || null, p_status: h.status || null, p_motorist: h.motorist || null,
            p_from: h.from || null, p_to: h.to || null, p_limit: PAGE, p_offset: h.page * PAGE,
          });
          if (stale(my)) return;
          const pages = Math.max(1, Math.ceil(r.total / PAGE));
          box.innerHTML = `<p class="muted small">${r.total} resultado(s)</p>` +
            (r.rows.length ? r.rows.map(invRow).join('') : '<div class="empty">Sin resultados.</div>') +
            (r.total > PAGE ? `<div class="pager"><button class="btn sm" id="pv" ${h.page === 0 ? 'disabled' : ''} type="button">← Anterior</button>
              <span class="muted small">Página ${h.page + 1} de ${pages}</span>
              <button class="btn sm" id="nx" ${h.page + 1 >= pages ? 'disabled' : ''} type="button">Siguiente →</button></div>` : '');
          bindInvRows(box);
          const pv = $('#pv', box), nx = $('#nx', box);
          if (pv) pv.addEventListener('click', () => { h.page--; loadResults(my); });
          if (nx) nx.addEventListener('click', () => { h.page++; loadResults(my); });
        } catch (e) { if (!stale(my)) box.innerHTML = `<div class="error-box">${esc(CD.errMsg(e))}</div>`; }
      }

      // ---------- DETALLE DE FACTURA ----------
      async function showInvoice(id) {
        const sh = CD.sheet('Factura', '<div class="loading-box"><div class="spinner"></div></div>');
        let changed = false;
        try { await state.settingsReady; } catch (e) { /* se usa la plantilla por defecto */ }
        sh.onClose = () => { if (changed) render(); };
        async function refresh() {
          try {
            const d = await CD.rpc('get_invoice_detail', { p_invoice_id: id });
            paint(d);
          } catch (e) { sh.body.innerHTML = `<div class="error-box">${esc(CD.errMsg(e))}</div>`; }
        }
        function paint(d) {
          const i = d.invoice;
          sh.setTitle(i.invoice_number);
          const done = i.status === 'completed' || i.status === 'sent';
          const evNames = { created: 'Creada', assigned: 'Asignada', reassigned: 'Reasignada', completed: 'Completada por el motorizado', sent: 'Marcada como enviada', corrected: 'Corregida por el administrador', cancelled: 'Anulada' };
          sh.body.innerHTML = `
            <div class="row between mb">${CD.badge(i.status)}<span class="muted small">${esc(CD.fmtDT(i.created_at))}</span></div>
            <div class="kv"><span class="k">Cliente</span><span class="v">${esc(i.customer_name)}</span></div>
            <div class="kv"><span class="k">Teléfono</span><span class="v">${esc(i.customer_phone)}</span></div>
            <div class="kv"><span class="k">Dirección</span><span class="v">${esc(i.delivery_address)}</span></div>
            <div class="kv"><span class="k">Motorizado asignado</span><span class="v">${esc(i.motorist_name)}</span></div>
            ${done ? `<div class="kv"><span class="k">Completada por</span><span class="v">${esc(i.completed_by_name || '—')}<br><span class="muted small">${esc(CD.fmtDT(i.completed_at))}</span></span></div>` : ''}
            ${i.sent_at ? `<div class="kv"><span class="k">Enviada</span><span class="v">${esc(CD.fmtDT(i.sent_at))}</span></div>` : ''}
            ${i.status === 'cancelled' ? `<div class="kv"><span class="k">Motivo de anulación</span><span class="v">${esc(i.cancel_reason)}</span></div>` : ''}
            <div class="kv"><span class="k">Monto gastado</span><span class="v">${i.amount_spent == null ? '—' : money(i.amount_spent)}</span></div>
            <div class="kv"><span class="k">Costo del delivery</span><span class="v">${money(i.delivery_fee)}</span></div>
            <div class="kv total"><span class="k">Total a pagar</span><span class="v">${i.total == null ? '—' : money(i.total)}</span></div>
            <div class="actions" id="acts"></div>
            <h3 class="mt">Historial</h3>
            <ul class="timeline">${d.events.map((ev) => `<li><b>${esc(evNames[ev.event_type] || ev.event_type)}</b>
              <div class="muted small">${esc(CD.fmtDT(ev.created_at))} · ${esc(ev.actor || '—')}</div>
              ${evDetail(ev)}</li>`).join('')}</ul>`;
          const acts = $('#acts', sh.body);
          const add = (html, fn) => { const b = document.createElement('span'); b.innerHTML = html; const el = b.firstElementChild; acts.appendChild(el); if (fn) el.addEventListener('click', fn); return el; };
          if (done) {
            add(`<a class="btn wa" target="_blank" rel="noopener" href="${esc(CD.waLink(i.customer_phone, fillTemplate(i)))}">💬 ${i.status === 'sent' ? 'Reenviar' : 'Enviar'} factura por WhatsApp</a>`);
          }
          if (i.status === 'completed') {
            const b = add('<button class="btn green" type="button">✔ Ya la envié: marcar como enviada</button>');
            b.addEventListener('click', () => CD.withBusy(b, async () => {
              const ok = await CD.confirm('Confirma que ya enviaste el mensaje al cliente por WhatsApp. Abrir WhatsApp no garantiza que se haya enviado.', { okText: 'Sí, ya la envié' });
              if (!ok) return;
              try { await CD.rpc('mark_invoice_sent', { p_invoice_id: id }); CD.ok('Factura marcada como enviada.'); changed = true; await refresh(); } catch (e) { CD.fail(e); }
            }));
          }
          if (i.status === 'pending') add('<button class="btn" type="button">🔁 Reasignar</button>', () => reassignSheet(i, () => { changed = true; refresh(); }));
          if (i.status !== 'cancelled') add('<button class="btn" type="button">✏️ Corregir montos</button>', () => correctSheet(i, () => { changed = true; refresh(); }));
          if (i.status !== 'cancelled') add('<button class="btn danger" type="button">Anular</button>', () => cancelSheet(i, () => { changed = true; refresh(); }));
        }
        function evDetail(ev) {
          const d = ev.details || {};
          if (ev.event_type === 'corrected') return `<div class="small">Motivo: ${esc(d.reason)}<br>Antes: gastado ${d.old && d.old.amount_spent != null ? money(d.old.amount_spent) : '—'}, delivery ${money(d.old && d.old.delivery_fee)}<br>Ahora: gastado ${d.new && d.new.amount_spent != null ? money(d.new.amount_spent) : '—'}, delivery ${money(d.new && d.new.delivery_fee)}</div>`;
          if (ev.event_type === 'completed') return `<div class="small">Monto gastado ${money(d.amount_spent)} · Total ${money(d.total)}</div>`;
          if (ev.event_type === 'cancelled') return `<div class="small">Motivo: ${esc(d.reason)}</div>`;
          if (d.motorist && (ev.event_type === 'assigned' || ev.event_type === 'reassigned')) return `<div class="small">Motorizado: ${esc(d.motorist)}</div>`;
          return '';
        }
        await refresh();
      }

      async function reassignSheet(inv, done) {
        const mots = await loadMotorists(true);
        const sh = CD.sheet('Reasignar ' + inv.invoice_number, `
          <div class="field"><label>Nuevo motorizado</label><select id="m">${mots.map((m) => `<option value="${esc(m.id)}" ${m.id === inv.assigned_motorist_id ? 'selected' : ''}>${esc(m.full_name)}</option>`).join('')}</select></div>
          <button class="btn primary block" id="go" type="button">Reasignar</button>`);
        const b = $('#go', sh.body);
        b.addEventListener('click', () => CD.withBusy(b, async () => {
          try { await CD.rpc('reassign_invoice', { p_invoice_id: inv.id, p_motorist_id: $('#m', sh.body).value }); CD.ok('Factura reasignada.'); sh.close(); done(); } catch (e) { CD.fail(e); }
        }));
      }
      function correctSheet(inv, done) {
        const canAmt = inv.status !== 'pending';
        const sh = CD.sheet('Corregir ' + inv.invoice_number, `
          <div class="field"><label>Costo del delivery (C$)</label><input id="fee" inputmode="decimal" value="${esc(inv.delivery_fee)}"></div>
          ${canAmt ? `<div class="field"><label>Monto gastado (C$)</label><input id="amt" inputmode="decimal" value="${esc(inv.amount_spent)}"></div>` : ''}
          <div class="field"><label>Motivo de la corrección (queda en el historial)</label><textarea id="why"></textarea></div>
          <button class="btn primary block" id="go" type="button">Guardar corrección</button>`);
        const b = $('#go', sh.body);
        b.addEventListener('click', () => CD.withBusy(b, async () => {
          const fee = CD.parseAmount($('#fee', sh.body).value);
          const amt = canAmt ? CD.parseAmount($('#amt', sh.body).value) : null;
          const why = $('#why', sh.body).value.trim();
          if (fee === null || (canAmt && amt === null)) return CD.fail('Revisa los montos.');
          if (why.length < 3) return CD.fail(CD.errMsg({ message: 'motivo_requerido' }));
          try {
            await CD.rpc('admin_update_invoice', { p_invoice_id: inv.id, p_delivery_fee: fee, p_amount_spent: canAmt ? amt : null, p_reason: why });
            CD.ok('Corrección guardada.'); sh.close(); done();
          } catch (e) { CD.fail(e); }
        }));
      }
      function cancelSheet(inv, done) {
        const sh = CD.sheet('Anular ' + inv.invoice_number, `
          <p class="muted">La factura no se borra: queda anulada en el historial y deja de contar en las estadísticas.</p>
          <div class="field"><label>Motivo</label><textarea id="why"></textarea></div>
          <button class="btn danger block" id="go" type="button">Anular factura</button>`);
        const b = $('#go', sh.body);
        b.addEventListener('click', () => CD.withBusy(b, async () => {
          const why = $('#why', sh.body).value.trim();
          if (why.length < 3) return CD.fail(CD.errMsg({ message: 'motivo_requerido' }));
          try { await CD.rpc('cancel_invoice', { p_invoice_id: inv.id, p_reason: why }); CD.ok('Factura anulada.'); sh.close(); done(); } catch (e) { CD.fail(e); }
        }));
      }

      // ---------- MOTORIZADOS ----------
      async function callAdminFn(action, payload) {
        const { data: s } = await CD.sb.auth.getSession();
        const token = s && s.session ? s.session.access_token : '';
        let res;
        try {
          res = await fetch('/.netlify/functions/admin-users', {
            method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token },
            body: JSON.stringify(Object.assign({ action }, payload)),
          });
        } catch (e) { throw new Error('Failed to fetch'); }
        let body = {};
        try { body = await res.json(); } catch (e) { /* vacío */ }
        if (!res.ok) throw new Error(body.error || 'Error del servidor (' + res.status + ')');
        return body;
      }

      async function vMotorists(my) {
        const list = await CD.rpc('motorists_summary');
        if (stale(my)) return;
        state.motorists = list;
        view.innerHTML = `
          <div class="row between mb"><h2 style="margin:0">Motorizados</h2><button class="btn primary sm" id="add" type="button">➕ Agregar</button></div>
          ${list.length ? list.map((m) => `
            <div class="card" data-id="${esc(m.id)}">
              <div class="inv-top"><span class="inv-name">${esc(m.full_name)}</span><span class="badge ${m.active ? 'on' : 'off'}">${m.active ? 'Activo' : 'Desactivado'}</span></div>
              <div class="inv-line">👤 ${esc(m.username)} · Registro: ${esc(CD.fmtDate(m.created_at))}</div>
              <div class="inv-line">Pendientes: <b>${m.pending}</b> · Completadas: <b>${m.completed}</b></div>
              <div class="actions">
                <button class="btn sm" data-a="orders" type="button">📋 Asignaciones</button>
                <button class="btn sm" data-a="edit" type="button">✏️ Editar</button>
                <button class="btn sm" data-a="pw" type="button">🔑 Contraseña</button>
                <button class="btn sm ${m.active ? 'danger' : 'green'}" data-a="toggle" type="button">${m.active ? 'Desactivar' : 'Activar'}</button>
              </div></div>`).join('') : '<div class="empty">Aún no hay motorizados. Agrega el primero.</div>'}`;
        $('#add', view).addEventListener('click', addMotoristSheet);
        view.onclick = onMotClick;
        function onMotClick(e) {
          const b = e.target.closest('[data-a]'); if (!b) return;
          const m = state.motorists.find((x) => x.id === b.closest('[data-id]').dataset.id); if (!m) return;
          if (b.dataset.a === 'orders') go('invoices', { hist: { q: '', status: '', motorist: m.id, from: '', to: '' } });
          if (b.dataset.a === 'edit') editMotoristSheet(m);
          if (b.dataset.a === 'pw') resetPwSheet(m);
          if (b.dataset.a === 'toggle') toggleMotorist(m, b);
        }
      }

      function pwField(id) {
        return `<div class="field"><label>Contraseña (mínimo 8 caracteres)</label>
          <div class="pw-row"><input id="${id}" type="text" autocomplete="off" maxlength="72"><button class="btn sm" data-gen type="button">Generar</button></div>
          <div class="hint">Entrégasela al motorizado por un medio privado. Podrá cambiarla desde su panel.</div></div>`;
      }
      function bindGen(scope, id) {
        $('[data-gen]', scope).addEventListener('click', () => { $('#' + id, scope).value = CD.randomPassword(10); });
      }
      function addMotoristSheet() {
        const sh = CD.sheet('Agregar motorizado', `
          <div class="field"><label>Nombre completo</label><input id="fn" autocomplete="off" maxlength="100"></div>
          <div class="field"><label>Nombre de usuario</label><input id="un" autocomplete="off" autocapitalize="none" maxlength="30" placeholder="carlos"><div class="hint">Solo minúsculas, números, punto, guion y guion bajo (3 a 30).</div></div>
          ${pwField('pw')}
          <button class="btn primary block" id="go" type="button">Crear cuenta</button>`);
        bindGen(sh.body, 'pw');
        const b = $('#go', sh.body);
        b.addEventListener('click', () => CD.withBusy(b, async () => {
          const full_name = $('#fn', sh.body).value.trim(), username = $('#un', sh.body).value.trim().toLowerCase(), password = $('#pw', sh.body).value;
          if (full_name.length < 2) return CD.fail('Escribe el nombre completo.');
          if (!/^[a-z0-9._-]{3,30}$/.test(username)) return CD.fail('Usuario inválido (3-30 caracteres: minúsculas, números, . _ -).');
          if (password.length < 8) return CD.fail('La contraseña debe tener al menos 8 caracteres.');
          try {
            await callAdminFn('create', { full_name, username, password });
            sh.setTitle('Cuenta creada ✔');
            sh.body.innerHTML = `<div class="info-box">Anota estos datos y entrégalos al motorizado. La contraseña no se vuelve a mostrar.</div>
              <div class="kv"><span class="k">Usuario</span><span class="v">${esc(username)}</span></div>
              <div class="kv"><span class="k">Contraseña</span><span class="v">${esc(password)}</span></div>
              <button class="btn primary block mt" id="ok" type="button">Listo</button>`;
            $('#ok', sh.body).addEventListener('click', () => { sh.close(); render(); });
            sh.onClose = render;
          } catch (e) { CD.fail(e); }
        }));
      }
      function editMotoristSheet(m) {
        const sh = CD.sheet('Editar motorizado', `
          <div class="field"><label>Nombre completo</label><input id="fn" value="${esc(m.full_name)}" maxlength="100"></div>
          <div class="field"><label>Nombre de usuario</label><input id="un" value="${esc(m.username)}" autocapitalize="none" maxlength="30"></div>
          <button class="btn primary block" id="go" type="button">Guardar</button>`);
        const b = $('#go', sh.body);
        b.addEventListener('click', () => CD.withBusy(b, async () => {
          try {
            await callAdminFn('update', { id: m.id, full_name: $('#fn', sh.body).value.trim(), username: $('#un', sh.body).value.trim().toLowerCase() });
            CD.ok('Perfil actualizado.'); sh.close(); render();
          } catch (e) { CD.fail(e); }
        }));
      }
      function resetPwSheet(m) {
        const sh = CD.sheet('Nueva contraseña: ' + m.full_name, `${pwField('pw')}<button class="btn primary block" id="go" type="button">Restablecer contraseña</button>`);
        bindGen(sh.body, 'pw');
        const b = $('#go', sh.body);
        b.addEventListener('click', () => CD.withBusy(b, async () => {
          const password = $('#pw', sh.body).value;
          if (password.length < 8) return CD.fail('La contraseña debe tener al menos 8 caracteres.');
          try { await callAdminFn('reset_password', { id: m.id, password }); CD.ok('Contraseña restablecida. Entrégasela al motorizado.'); sh.close(); } catch (e) { CD.fail(e); }
        }));
      }
      async function toggleMotorist(m, btn) {
        const next = !m.active;
        const ok = await CD.confirm(next ? `¿Activar la cuenta de ${m.full_name}?` : `¿Desactivar la cuenta de ${m.full_name}? No podrá entrar al sistema.`, { okText: next ? 'Activar' : 'Desactivar', danger: !next });
        if (!ok) return;
        CD.withBusy(btn, async () => {
          try { await callAdminFn('set_active', { id: m.id, active: next }); CD.ok(next ? 'Cuenta activada.' : 'Cuenta desactivada.'); render(); } catch (e) { CD.fail(e); }
        });
      }

      // ---------- CLIENTES ----------
      async function vCustomers(my) {
        let term = '', page = 0;
        view.innerHTML = `<h2>Clientes</h2><div class="field"><input id="cs" type="search" placeholder="Buscar por nombre o teléfono" autocomplete="off"></div><div id="cl"></div>`;
        async function load() {
          const cl = $('#cl', view);
          cl.innerHTML = '<div class="loading-box"><div class="spinner"></div></div>';
          try {
            const { data, count } = await CD.q(() => {
              let q = CD.sb.from('customers').select('id,name,phone,address,created_at,invoices(count)', { count: 'exact' })
                .order('created_at', { ascending: false }).range(page * PAGE, page * PAGE + PAGE - 1);
              const safe = term.replace(/[%,()*]/g, ' ').trim(), digits = term.replace(/\D/g, '');
              if (safe) q = digits.length >= 3 ? q.or(`name.ilike.%${safe}%,phone_norm.ilike.%${digits}%`) : q.ilike('name', `%${safe}%`);
              return q;
            });
            if (stale(my)) return;
            const pages = Math.max(1, Math.ceil((count || 0) / PAGE));
            cl.innerHTML = `<p class="muted small">${count || 0} cliente(s)</p>` +
              ((data || []).length ? data.map((c) => `<div class="card click" data-ph="${esc(c.phone)}">
                <div class="inv-name">${esc(c.name)}</div><div class="inv-line">📞 ${esc(c.phone)}</div>
                ${c.address ? `<div class="inv-line">📍 ${esc(c.address)}</div>` : ''}
                <div class="inv-line">Facturas: <b>${c.invoices && c.invoices[0] ? c.invoices[0].count : 0}</b> · Desde ${esc(CD.fmtDate(c.created_at))}</div></div>`).join('') : '<div class="empty">Sin clientes.</div>') +
              ((count || 0) > PAGE ? `<div class="pager"><button class="btn sm" id="pv" ${page === 0 ? 'disabled' : ''} type="button">← Anterior</button><span class="muted small">Página ${page + 1} de ${pages}</span><button class="btn sm" id="nx" ${page + 1 >= pages ? 'disabled' : ''} type="button">Siguiente →</button></div>` : '');
            $$('[data-ph]', cl).forEach((el) => el.addEventListener('click', () => go('invoices', { hist: { q: el.dataset.ph, status: '', motorist: '', from: '', to: '' } })));
            const pv = $('#pv', cl), nx = $('#nx', cl);
            if (pv) pv.addEventListener('click', () => { page--; load(); });
            if (nx) nx.addEventListener('click', () => { page++; load(); });
          } catch (e) { cl.innerHTML = `<div class="error-box">${esc(CD.errMsg(e))}</div>`; }
        }
        $('#cs', view).addEventListener('input', CD.debounce((e) => { term = e.target.value.trim(); page = 0; load(); }, 400));
        await load();
      }

      // ---------- CONFIGURACIÓN ----------
      async function vSettings(my) {
        await loadSettings();
        if (stale(my)) return;
        const s = state.settings;
        view.innerHTML = `
          <h2>Configuración</h2>
          <div class="card">
            <div class="field"><label>Nombre del negocio</label><input id="bn" value="${esc(s.business_name || 'Chepe Delivery')}" maxlength="80"></div>
            <div class="field"><label>Costo de delivery sugerido (C$)</label><input id="df" inputmode="decimal" value="${esc(s.default_delivery_fee != null ? s.default_delivery_fee : 50)}"></div>
            <div class="field"><label>Mensaje de WhatsApp</label><textarea id="tp" style="min-height:240px">${esc(s.whatsapp_template || DEFAULT_TPL)}</textarea>
              <div class="hint">Variables: {cliente} {negocio} {factura} {fecha} {monto} {delivery} {total}. Los montos van sin «C$», ponlo tú en el texto.</div></div>
            <div class="actions"><button class="btn ghost" id="rs" type="button">Restaurar mensaje original</button><button class="btn primary" id="sv" type="button">Guardar</button></div>
          </div>`;
        $('#rs', view).addEventListener('click', () => { $('#tp', view).value = DEFAULT_TPL; });
        const b = $('#sv', view);
        b.addEventListener('click', () => CD.withBusy(b, async () => {
          const fee = CD.parseAmount($('#df', view).value);
          const name = $('#bn', view).value.trim(), tpl = $('#tp', view).value;
          if (fee === null) return CD.fail('El costo de delivery no es válido.');
          if (!name) return CD.fail('Escribe el nombre del negocio.');
          if (tpl.trim().length < 10) return CD.fail('El mensaje de WhatsApp es muy corto.');
          try {
            const rows = [['business_name', name], ['default_delivery_fee', fee], ['whatsapp_template', tpl]]
              .map(([key, value]) => ({ key, value, updated_by: profile.id, updated_at: new Date().toISOString() }));
            const { error } = await CD.sb.from('settings').upsert(rows, { onConflict: 'key' });
            if (error) throw error;
            await loadSettings(); CD.ok('Configuración guardada.');
          } catch (e) { CD.fail(e); }
        }));
      }

      // ---------- NOTIFICACIONES ----------
      async function refreshBadge() {
        try {
          const { count } = await CD.q(() => CD.sb.from('invoice_notifications').select('id', { count: 'exact', head: true }).is('read_at', null));
          state.unread = count || 0;
          const dot = $('#aDot', root);
          dot.textContent = state.unread > 99 ? '99+' : state.unread;
          dot.hidden = !state.unread;
        } catch (e) { /* silencioso */ }
      }
      async function openNotifications() {
        const sh = CD.sheet('Notificaciones', '<div class="loading-box"><div class="spinner"></div></div>');
        sh.onClose = refreshBadge;
        try {
          const { data } = await CD.q(() => CD.sb.from('invoice_notifications').select('*').order('created_at', { ascending: false }).limit(30));
          if (!data.length) { sh.body.innerHTML = '<div class="empty">Sin notificaciones.</div>'; return; }
          sh.body.innerHTML = `<button class="btn sm ghost mb" id="allr" type="button">Marcar todas como leídas</button>` +
            data.map((n) => `<div class="card click" data-n="${esc(n.id)}" data-inv="${esc(n.invoice_id)}" style="${n.read_at ? 'opacity:.65' : 'border-color:var(--brand)'}">
              <div class="pre">${esc(n.message)}</div>
              <div class="row between mt"><span class="muted small">${esc(CD.fmtDT(n.created_at))}</span><b class="small" style="color:var(--brand)">Abrir factura →</b></div></div>`).join('');
          $('#allr', sh.body).addEventListener('click', async (e) => CD.withBusy(e.currentTarget, async () => {
            try { await CD.rpc('mark_notifications_read', {}); CD.ok('Listo.'); sh.close(); } catch (err) { CD.fail(err); }
          }));
          $$('[data-n]', sh.body).forEach((el) => el.addEventListener('click', async () => {
            CD.rpc('mark_notifications_read', { p_ids: [el.dataset.n] }, { retries: 0 }).catch(() => {});
            sh.close(); showInvoice(el.dataset.inv);
          }));
        } catch (e) { sh.body.innerHTML = `<div class="error-box">${esc(CD.errMsg(e))}</div>`; }
      }

      // ---------- TIEMPO REAL ----------
      const softRefresh = CD.debounce(() => { if (state.view === 'dashboard' || state.view === 'invoices') render(); }, 800);
      state.live = CD.live('admin-' + profile.id, [
        { event: 'INSERT', schema: 'public', table: 'invoice_notifications', filter: 'recipient_id=eq.' + profile.id },
        { event: 'UPDATE', schema: 'public', table: 'invoices' },
      ], (ev) => {
        if (ev && ev.table === 'invoice_notifications' && ev.new) {
          CD.toast('🔔 ' + ev.new.message, 'notify', 9000);
          if (navigator.vibrate) navigator.vibrate([200, 100, 200]);
        }
        refreshBadge();
        if (!document.querySelector('.overlay')) softRefresh();
      });

      // Arranque
      state.settingsReady = loadSettings();
      state.settingsReady.catch(() => {});
      refreshBadge();
      go('dashboard');

      return { destroy() { state.seq++; if (state.live) state.live.stop(); root.innerHTML = ''; } };
    },
  };
})();
