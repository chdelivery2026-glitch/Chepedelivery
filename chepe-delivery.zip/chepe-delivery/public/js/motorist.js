/* Panel del motorizado: simple y pensado para celular */
(function () {
  'use strict';
  const { esc, $, money } = CD;

  CD.motorist = {
    mount(root, profile) {
      let tab = 'pending';
      let live = null;
      let seq = 0;
      let data = { pending: [], done: [], doneCount: 0 };

      root.innerHTML = `
        <header class="topbar">
          <div class="brand">🛵 Chepe <span>Delivery</span></div>
          <button class="icon-btn" id="mPass" title="Cambiar contraseña" aria-label="Cambiar contraseña" type="button">🔑</button>
          <button class="icon-btn" id="mOut" title="Cerrar sesión" aria-label="Cerrar sesión" type="button">⎋</button>
        </header>
        <main class="view">
          <h2>Hola, ${esc(profile.full_name)} 👋</h2>
          <div class="grid" style="grid-template-columns:1fr 1fr">
            <div class="tile brand"><div class="lbl">Pedidos pendientes</div><div class="val" id="mPend">–</div></div>
            <div class="tile"><div class="lbl">Pedidos completados</div><div class="val" id="mDone">–</div></div>
          </div>
          <div class="seg" id="mSeg">
            <button data-t="pending" class="active" type="button">Pendientes</button>
            <button data-t="done" type="button">Completadas</button>
          </div>
          <div id="mList"><div class="loading-box"><div class="spinner"></div></div></div>
          <button class="btn ghost block mt" id="mRefresh" type="button">↻ Actualizar</button>
        </main>`;

      $('#mOut', root).addEventListener('click', () => CD.logout());
      $('#mPass', root).addEventListener('click', () => CD.changePasswordSheet());
      $('#mRefresh', root).addEventListener('click', (e) => CD.withBusy(e.currentTarget, load));
      $('#mSeg', root).addEventListener('click', (e) => {
        const b = e.target.closest('button[data-t]'); if (!b) return;
        tab = b.dataset.t;
        CD.$$('#mSeg button', root).forEach((x) => x.classList.toggle('active', x === b));
        renderList();
      });

      const SEL = 'id,invoice_number,status,delivery_fee,amount_spent,total,delivery_address,assigned_at,completed_at,customer:customers(name,phone)';

      async function load() {
        const my = ++seq;
        try {
          const [p, d] = await Promise.all([
            CD.q(() => CD.sb.from('invoices').select(SEL).eq('status', 'pending').order('assigned_at', { ascending: false })),
            CD.q(() => CD.sb.from('invoices').select(SEL, { count: 'exact' }).in('status', ['completed', 'sent']).order('completed_at', { ascending: false }).limit(30)),
          ]);
          if (my !== seq) return;
          data = { pending: p.data || [], done: d.data || [], doneCount: d.count || 0 };
          $('#mPend', root).textContent = data.pending.length;
          $('#mDone', root).textContent = data.doneCount;
          renderList();
          // las notificaciones de asignación ya se vieron en pantalla
          CD.rpc('mark_notifications_read', {}, { retries: 0 }).catch(() => {});
        } catch (e) {
          if (my !== seq) return;
          $('#mList', root).innerHTML = `<div class="error-box">${esc(CD.errMsg(e))}</div>`;
        }
      }

      function card(inv) {
        const c = inv.customer || {};
        const pend = inv.status === 'pending';
        return `<div class="card" data-id="${esc(inv.id)}">
          <div class="inv-top"><span class="inv-num">${esc(inv.invoice_number)}</span>${CD.badge(inv.status)}</div>
          <div class="inv-name">${esc(c.name)}</div>
          <div class="inv-line">📞 ${esc(c.phone)}</div>
          <div class="inv-line">📍 ${esc(inv.delivery_address)}</div>
          <div class="inv-line">🕒 Asignada: ${esc(CD.fmtDT(inv.assigned_at))}</div>
          <div class="row between mt"><span class="muted">Costo del delivery</span><span class="inv-fee">${money(inv.delivery_fee)}</span></div>
          ${pend ? '' : `<div class="row between"><span class="muted">Monto gastado</span><b>${money(inv.amount_spent)}</b></div>
                         <div class="inv-line">✅ Completada: ${esc(CD.fmtDT(inv.completed_at))}</div>`}
          <div class="actions">
            <a class="btn sm" href="tel:${esc(c.phone)}">📞 Llamar</a>
            <a class="btn sm" target="_blank" rel="noopener" href="${esc(CD.mapsLink(inv.delivery_address))}">🗺️ Mapa</a>
            ${pend ? `<button class="btn primary" data-complete="${esc(inv.id)}" type="button">Completar factura</button>` : ''}
          </div></div>`;
      }

      function renderList() {
        const list = tab === 'pending' ? data.pending : data.done;
        const box = $('#mList', root);
        if (!list.length) {
          box.innerHTML = `<div class="empty">${tab === 'pending' ? '🎉 No tienes pedidos pendientes.' : 'Aún no has completado pedidos.'}</div>`;
          return;
        }
        box.innerHTML = list.map(card).join('') +
          (tab === 'done' && data.doneCount > list.length ? `<p class="muted small right">Mostrando las últimas ${list.length} de ${data.doneCount}.</p>` : '');
      }

      $('#mList', root).addEventListener('click', (e) => {
        const b = e.target.closest('[data-complete]'); if (!b) return;
        const inv = data.pending.find((x) => x.id === b.dataset.complete);
        if (inv) completeSheet(inv);
      });

      function completeSheet(inv) {
        const c = inv.customer || {};
        const sh = CD.sheet(inv.invoice_number, `
          <p><b>${esc(c.name)}</b><br><span class="muted">${esc(inv.delivery_address)}</span></p>
          <div class="kv"><span class="k">Costo del delivery</span><span class="v">${money(inv.delivery_fee)}</span></div>
          <div class="field mt">
            <label for="amt">Monto gastado en el pedido: C$</label>
            <input id="amt" class="amount-input" inputmode="decimal" autocomplete="off" placeholder="0.00">
            <div class="hint">Puedes poner 0 si no hubo gasto. Después de completar no podrás cambiarlo.</div>
          </div>
          <button class="btn primary block" id="go" type="button">Completar factura</button>`);
        const inp = sh.body.querySelector('#amt');
        setTimeout(() => inp.focus(), 150);
        const go = sh.body.querySelector('#go');
        go.addEventListener('click', () => CD.withBusy(go, async () => {
          const amount = CD.parseAmount(inp.value);
          if (amount === null) return CD.fail('Escribe un monto válido, por ejemplo 180 o 180.50 (puede ser 0).');
          const ok = await CD.confirm(`Factura ${inv.invoice_number}\nMonto gastado: ${money(amount)}\n\nNo podrás modificarlo después. ¿Completar?`, { okText: 'Sí, completar' });
          if (!ok) return;
          try {
            await CD.rpc('complete_invoice', { p_invoice_id: inv.id, p_amount: amount });
            CD.ok('Factura completada. El administrador fue notificado.');
            sh.close();
          } catch (e) {
            if (String(e.message).includes('ya_completada')) { CD.fail(e); sh.close(); }
            else CD.fail(e);
          }
          load();
        }));
      }

      // Realtime: nuevas asignaciones aparecen solas
      live = CD.live('motorist-' + profile.id, [
        { event: '*', schema: 'public', table: 'invoices', filter: 'assigned_motorist_id=eq.' + profile.id },
        { event: 'INSERT', schema: 'public', table: 'invoice_notifications', filter: 'recipient_id=eq.' + profile.id },
      ], (() => {
        const reload = CD.debounce(load, 400);
        return (ev) => {
          if (ev && ev.table === 'invoice_notifications' && ev.new) {
            CD.toast('🛵 ' + ev.new.message, 'notify', 7000);
            if (navigator.vibrate) navigator.vibrate(200);
          }
          reload();
        };
      })());

      load();
      return { destroy() { seq++; if (live) live.stop(); root.innerHTML = ''; } };
    },
  };
})();
