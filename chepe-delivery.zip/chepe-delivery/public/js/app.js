/* Arranque: configuración, inicio de sesión y enrutamiento por rol */
(function () {
  'use strict';
  const { esc } = CD;
  const root = document.getElementById('app');
  let panel = null;

  function destroyPanel() {
    if (panel && panel.destroy) panel.destroy();
    panel = null;
  }

  function showFatal(msg) {
    root.innerHTML = `<div class="login-wrap"><div class="logo"><div class="mark">⚠️</div><div class="name">Configuración incompleta</div></div>
      <div class="error-box">${esc(msg)}</div>
      <button class="btn block" onclick="location.reload()" type="button">Reintentar</button></div>`;
  }

  function showLogin(message) {
    destroyPanel();
    root.innerHTML = `
      <div class="login-wrap">
        <div class="logo"><div class="mark">🛵</div><div class="name">Chepe <span>Delivery</span></div><div class="muted">Sistema de pedidos y facturación</div></div>
        ${message ? `<div class="error-box">${esc(message)}</div>` : ''}
        <form id="lf" novalidate>
          <div class="field"><label for="u">Usuario</label><input id="u" autocomplete="username" autocapitalize="none" autocorrect="off" spellcheck="false"></div>
          <div class="field"><label for="p">Contraseña</label>
            <div class="pw-row"><input id="p" type="password" autocomplete="current-password"><button class="btn sm" id="tg" type="button" aria-label="Mostrar contraseña">👁</button></div></div>
          <button class="btn primary block" id="go" type="submit">Entrar</button>
        </form>
      </div>`;
    const p = document.getElementById('p');
    document.getElementById('tg').addEventListener('click', () => { p.type = p.type === 'password' ? 'text' : 'password'; });
    document.getElementById('lf').addEventListener('submit', (e) => {
      e.preventDefault();
      CD.withBusy(document.getElementById('go'), async () => {
        const user = document.getElementById('u').value.trim().toLowerCase();
        const pass = p.value;
        if (!user || !pass) return CD.fail('Escribe tu usuario y contraseña.');
        const email = user.includes('@') ? user : `${user}@${CD.cfg.emailDomain}`;
        const { data, error } = await CD.sb.auth.signInWithPassword({ email, password: pass });
        if (error) return CD.fail(error);
        await enter(data.user);
      });
    });
  }

  async function enter(user) {
    let profile = null;
    try {
      const { data, error } = await CD.sb.from('profiles').select('*').eq('id', user.id).maybeSingle();
      if (error) throw error;
      profile = data;
    } catch (e) {
      await CD.sb.auth.signOut();
      return showLogin(CD.errMsg(e));
    }
    if (!profile || !profile.active) {
      await CD.sb.auth.signOut();
      return showLogin(!profile ? 'Tu usuario no tiene un perfil asignado. Contacta al administrador.' : 'Tu cuenta está desactivada. Contacta al administrador.');
    }
    CD.profile = profile;
    destroyPanel();
    panel = profile.role === 'admin' ? CD.admin.mount(root, profile) : CD.motorist.mount(root, profile);
  }

  CD.logout = async () => {
    destroyPanel();
    try { await CD.sb.auth.signOut(); } catch (e) { /* ignorar */ }
    showLogin();
  };

  async function boot() {
    let cfg;
    try {
      const res = await fetch('/.netlify/functions/config', { cache: 'no-store' });
      cfg = await res.json();
      if (!res.ok || cfg.error) throw new Error(cfg.error || 'No se pudo leer la configuración.');
    } catch (e) {
      return showFatal('No se pudo cargar la configuración del servidor. Revisa las variables de entorno en Netlify. (' + e.message + ')');
    }
    if (!window.supabase) return showFatal('No se pudo cargar la librería de Supabase. Revisa tu conexión a Internet.');
    CD.cfg = cfg;
    CD.sb = window.supabase.createClient(cfg.supabaseUrl, cfg.supabaseAnonKey, {
      auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: false },
    });
    // Solo acciones síncronas aquí (no llamar a Supabase dentro de este callback)
    CD.sb.auth.onAuthStateChange((evt) => { if (evt === 'SIGNED_OUT' && !panel) showLogin(); });

    const { data } = await CD.sb.auth.getSession();
    if (data && data.session) await enter(data.session.user);
    else showLogin();

    // Al volver a la app, verificar que la cuenta siga activa
    document.addEventListener('visibilitychange', async () => {
      if (document.hidden || !panel || !CD.profile) return;
      try {
        const { data: p, error } = await CD.sb.from('profiles').select('active,role').eq('id', CD.profile.id).maybeSingle();
        if (error) return;
        if (!p || !p.active || p.role !== CD.profile.role) { await CD.logout(); CD.toast('Tu sesión se cerró: la cuenta cambió o fue desactivada.', 'err', 7000); }
      } catch (e) { /* sin conexión: se reintenta luego */ }
    });
  }

  boot();
})();
