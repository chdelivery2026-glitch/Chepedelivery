# Chepe Delivery – Sistema de pedidos y facturación

Aplicación web (HTML + CSS + JavaScript) con base de datos compartida en **Supabase** y alojada en **Netlify**.
Funciona en el navegador del celular (Android) y de la computadora. Tiene dos tipos de cuenta:

- **Administrador:** panel, nueva factura, historial, motorizados, clientes, notificaciones y configuración.
- **Motorizado:** ve solo sus pedidos, ingresa el monto gastado y completa la factura.

## Cómo funciona el flujo

1. El administrador crea una factura y la asigna a un motorizado.
2. El motorizado la ve en su celular, ingresa el **monto gastado** y presiona «Completar factura».
3. El administrador recibe una notificación (en vivo si tiene la app abierta; guardada si no) con cliente, motorizado, factura, monto gastado, delivery y total.
4. El administrador abre la factura, presiona **«Enviar factura por WhatsApp»** (se abre WhatsApp con el mensaje listo), lo envía desde WhatsApp y luego presiona **«Ya la envié: marcar como enviada»**.

`Total a pagar = monto gastado + costo del delivery` (lo calcula la base de datos, no el navegador).

## Contenido del proyecto

| Archivo | Para qué sirve |
|---|---|
| `sql/01_esquema.sql` | Tablas, relaciones, índices, seguridad (RLS), funciones y Realtime |
| `sql/02_primer_admin.sql` | Crea el perfil del primer administrador |
| `public/` | La aplicación (index.html, css, js) |
| `netlify/functions/config.js` | Entrega al navegador solo la URL y la clave pública de Supabase |
| `netlify/functions/admin-users.js` | Crea/edita/desactiva motorizados y restablece contraseñas (usa la clave secreta, solo en el servidor) |
| `netlify.toml`, `package.json` | Configuración de Netlify |
| `.env.example` | Lista de variables de entorno (sin valores reales) |

## Qué ya está hecho y qué debes hacer tú

**Ya implementado en el código:** inicio de sesión real con Supabase Auth, roles, políticas de seguridad (RLS), facturas con número único automático y protección contra duplicados, completar factura de un solo uso, notificaciones persistentes + en vivo, mensaje de WhatsApp, historial con filtros y paginación, panel de estadísticas, gestión de motorizados, hora de Nicaragua.

**Lo debes hacer tú** (el código no puede hacerlo por ti): crear el proyecto de Supabase, ejecutar el SQL, crear el primer administrador, poner las variables de entorno en Netlify y publicar el sitio. Los pasos están abajo.

---

## Paso 1 – Crear el proyecto en Supabase (plan gratuito)

1. Entra a <https://supabase.com> y crea una cuenta.
2. **New project** → ponle nombre (por ejemplo `chepe-delivery`), elige una contraseña de base de datos (guárdala) y la región más cercana. Selecciona el plan **Free**.
3. Espera a que termine de crearse.

## Paso 2 – Ejecutar el SQL

1. En Supabase abre **SQL Editor** → **New query**.
2. Abre `sql/01_esquema.sql`, copia todo su contenido, pégalo y presiona **Run**. Debe terminar sin errores (puedes ejecutarlo de nuevo sin problema).

## Paso 3 – Ajustes de autenticación (importante)

En **Authentication**:

1. **Sign In / Providers → Email**: desactiva **«Allow new users to sign up»** (así nadie puede registrarse por su cuenta; las cuentas las crea el administrador).
2. Deja el proveedor Email activado.

## Paso 4 – Crear el primer administrador

1. **Authentication → Users → Add user → Create new user**.
2. Correo: `admin@chepedelivery.app` (el usuario es `admin`; el dominio `chepedelivery.app` es interno y **no necesita existir**).
3. Contraseña: una larga y privada. Marca **Auto Confirm User**.
4. Vuelve al **SQL Editor** y ejecuta `sql/02_primer_admin.sql`. Debe mostrarte una fila con `role = admin`.

Para entrar a la app usarás el usuario `admin` y esa contraseña.

## Paso 5 – Copiar las claves de Supabase

En **Project Settings → API** (o **API Keys**) copia:

- **Project URL**
- Clave **anon / publishable** (pública)
- Clave **service_role / secret** (**secreta: nunca la compartas ni la pegues en el código**)

## Paso 6 – Publicar en Netlify

El sitio incluye funciones de servidor, por lo que **no sirve arrastrar la carpeta a la página de Netlify**. Usa una de estas dos formas:

**Opción A – con GitHub (recomendada)**
1. Sube esta carpeta a un repositorio **privado** de GitHub (el `.gitignore` ya evita subir archivos sensibles).
2. En Netlify: **Add new site → Import an existing project** → elige el repositorio. Netlify detecta `netlify.toml`; no cambies nada.
3. Antes de publicar, en **Site configuration → Environment variables** agrega:

| Variable | Valor |
|---|---|
| `SUPABASE_URL` | Project URL |
| `SUPABASE_ANON_KEY` | clave anon / publishable |
| `SUPABASE_SERVICE_ROLE_KEY` | clave service_role / secret |
| `AUTH_EMAIL_DOMAIN` | `chepedelivery.app` (opcional) |

4. **Deploy**. Si agregaste las variables después, haz **Deploys → Trigger deploy → Clear cache and deploy site**.

**Opción B – con Netlify CLI** (desde tu computadora, dentro de la carpeta del proyecto):
```
npm install -g netlify-cli
npm install
netlify login
netlify init
netlify env:set SUPABASE_URL "https://TU-PROYECTO.supabase.co"
netlify env:set SUPABASE_ANON_KEY "..."
netlify env:set SUPABASE_SERVICE_ROLE_KEY "..."
netlify deploy --prod
```

## Paso 7 – Primer uso

1. Abre la URL de tu sitio de Netlify y entra con `admin` y tu contraseña.
2. Ve a **☰ → Motorizados → Agregar**. Escribe nombre, usuario (por ejemplo `carlos`) y contraseña (puedes usar «Generar»). Anota los datos y entrégalos al motorizado por un medio privado; podrá cambiar su contraseña desde su panel (botón 🔑).
3. Ve a **☰ → Configuración** y revisa el nombre del negocio, el costo de delivery sugerido y el mensaje de WhatsApp.
4. Opcional: en el celular, menú del navegador → «Agregar a pantalla de inicio».

## Seguridad – resumen

- Las facturas, eventos y notificaciones **no se pueden escribir directamente**: solo mediante funciones del servidor que verifican quién eres (`auth.uid()`).
- Un motorizado solo ve sus facturas y los clientes de esas facturas; no puede cambiar costos, cliente, motorizado, estado ni marcar «enviada».
- Nadie puede cambiarse el rol: los perfiles solo los modifica la función de Netlify, y esta solo acepta a un administrador activo.
- Un motorizado desactivado pierde el acceso a los datos de inmediato y su inicio de sesión queda bloqueado.
- La clave `service_role` vive solo en Netlify (servidor). La clave `anon` es pública por diseño; lo que protege los datos son las políticas RLS.
- El historial de eventos no se puede editar ni borrar desde la app. Las facturas no se eliminan: se **anulan** con motivo.
- Las correcciones de montos las hace solo el administrador y quedan registradas con el motivo.

## Criterios de las estadísticas

- **Ingresos por delivery** = suma de `delivery_fee` de facturas *completadas* o *enviadas* (por fecha de finalización).
- **Total bruto facturado** = suma de `monto gastado + delivery` de esas mismas facturas.
- **Facturas creadas** = creadas en el período, sin contar anuladas.
- **Pendientes / Completadas por enviar** = situación actual (no dependen del período). **Enviadas** = marcadas como enviadas en el período.
- Hoy, semana (desde el lunes) y mes se calculan en la hora de Nicaragua (America/Managua).

## Límites conocidos y plan gratuito

- **Notificaciones:** son dentro de la aplicación (en vivo mientras está abierta y guardadas si estaba cerrada). **No hay notificaciones push del teléfono**; eso requeriría configurar un servicio aparte.
- **WhatsApp:** se abre un enlace con el mensaje prellenado; **no se envía automáticamente**. Por eso la factura pasa a «enviada» solo cuando tú lo confirmas.
- **Plan gratuito de Supabase:** tiene límites de uso (espacio, tráfico, conexiones Realtime, etc.) y condiciones que el proveedor puede cambiar; por ejemplo, los proyectos gratuitos pueden **pausarse por inactividad**. Revisa los límites vigentes en <https://supabase.com/pricing>. No se garantiza que sea suficiente para siempre. La app ahorra recursos: Realtime solo con la pantalla visible, historiales paginados, índices, sin consultas repetitivas y sin archivos.
- Si un teléfono pierde conexión, la app reintenta automáticamente y, si falla, muestra un error; la factura **no** se marca completada hasta que la base de datos confirma.

## Lista de pruebas (hazlas tú en tus teléfonos)

1. Entrar como administrador (`admin`).
2. Crear un motorizado (☰ → Motorizados → Agregar).
3. Entrar como ese motorizado desde **otro teléfono**.
4. Crear una factura y asignarla a ese motorizado.
5. El motorizado la ve en «Pendientes» (aparece sola si tenía la app abierta).
6. Crear un 2.º motorizado y una factura para él: comprobar que el 1.º **no** la ve.
7. Comprobar que el motorizado no tiene ningún campo para editar el delivery.
8. El motorizado ingresa el monto gastado (prueba con `0` y con `180.50`) y completa la factura. Intentar completarla otra vez no es posible.
9. El administrador recibe la notificación (🔔) y ve los datos actualizados.
10. Verificar el total (gastado + delivery).
11. En la factura completada: «Enviar factura por WhatsApp» abre WhatsApp con el mensaje y el número del cliente.
12. Enviar el mensaje y presionar «Ya la envié». Revisar el historial y el detalle (eventos).
13. Cerrar sesión, cerrar el navegador y volver a entrar: los datos siguen ahí.
14. Desactivar al motorizado: ya no puede entrar. Reactivarlo: puede entrar de nuevo.
15. Revisar el diseño en Android (sin desplazamiento horizontal, botones cómodos).

### Qué se probó antes de entregarte este proyecto

- **Probado:** el esquema SQL completo en PostgreSQL 16 local (simulando las funciones de autenticación de Supabase): creación idempotente de facturas, deduplicación de clientes por teléfono, aislamiento entre motorizados, rechazo de escrituras directas y de cambios de rol, completar una sola vez, montos 0/negativo, cálculo del total, notificaciones solo para su destinatario, usuario desactivado sin acceso, rol `anon` sin acceso, estadísticas, búsqueda y detalle. También la validación de acceso de la función `admin-users` con un Supabase simulado, y la sintaxis de todos los archivos JavaScript.
- **No probado (necesita tus credenciales o teléfonos reales):** conexión con tu proyecto real de Supabase, el despliegue en Netlify, la creación real de cuentas en Supabase Auth, Realtime en vivo, apertura de WhatsApp, y el diseño en teléfonos Android reales (pruebas 1–3, 5, 9, 11 y 15 de la lista). Si algo falla en esos puntos, copia el mensaje de error y lo corregimos.
