-- =====================================================================
-- CHEPE DELIVERY - Esquema completo para Supabase (PostgreSQL)
-- Ejecutar completo en: Supabase > SQL Editor > New query > Run
-- Es re-ejecutable (usa "if not exists", "or replace" y "drop policy").
-- =====================================================================
--
-- MODELO DE SEGURIDAD
--  * Nadie escribe directo en facturas, eventos ni notificaciones: todo pasa por
--    funciones (RPC) "security definer" que validan el rol con auth.uid().
--  * RLS activo en todas las tablas. El rol "anon" no tiene acceso a nada.
--  * Las cuentas (auth.users + profiles) las crea/edita SOLO la función de Netlify
--    con la clave service_role (nunca expuesta en el navegador).
--
-- ESTADOS DE FACTURA
--  pending   -> asignada, esperando al motorizado
--  completed -> el motorizado ingresó el monto gastado (espera revisión/envío)
--  sent      -> el administrador confirmó que la envió por WhatsApp
--  cancelled -> anulada por el administrador (queda en el historial)
--
-- CRITERIO DE INGRESOS (el mismo en todas las pantallas)
--  Cuentan solo facturas en estado completed o sent, por fecha de finalización.
--  Ingresos por delivery = suma de delivery_fee
--  Total bruto facturado = suma de (amount_spent + delivery_fee)
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. FUNCIONES AUXILIARES BÁSICAS
-- ---------------------------------------------------------------------

create or replace function public.touch_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at := now();
  return new;
end $$;

-- Normaliza teléfonos: 8 dígitos => Nicaragua (505 + número)
create or replace function public.normalize_phone(p text)
returns text language sql immutable as $$
  select case
    when length(d) = 8 then '505' || d
    when length(d) = 11 and d like '505%' then d
    when length(d) = 13 and d like '00505%' then substr(d, 3)
    else d
  end
  from (select regexp_replace(coalesce(p, ''), '\D', '', 'g') as d) s
$$;

-- ---------------------------------------------------------------------
-- 2. TABLAS
-- ---------------------------------------------------------------------

create table if not exists public.profiles (
  id          uuid primary key references auth.users(id) on delete cascade,
  full_name   text not null check (char_length(btrim(full_name)) between 2 and 100),
  username    text not null check (username ~ '^[a-z0-9._-]{3,30}$'),
  role        text not null check (role in ('admin', 'motorizado')),
  active      boolean not null default true,
  created_at  timestamptz not null default now()
);
create unique index if not exists profiles_username_key on public.profiles (lower(username));
create index if not exists profiles_role_active_idx on public.profiles (role, active);

-- Funciones que dependen de profiles
create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles
                 where id = auth.uid() and role = 'admin' and active)
$$;

create or replace function public.is_motorist()
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles
                 where id = auth.uid() and role = 'motorizado' and active)
$$;

create or replace function public.is_active_user()
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles where id = auth.uid() and active)
$$;

create table if not exists public.customers (
  id          uuid primary key default gen_random_uuid(),
  name        text not null check (char_length(btrim(name)) between 1 and 120),
  phone       text not null,
  phone_norm  text not null,
  address     text,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create unique index if not exists customers_phone_norm_key on public.customers (phone_norm);
create index if not exists customers_name_idx on public.customers (lower(name));

create or replace function public.customers_before_write()
returns trigger language plpgsql as $$
begin
  new.phone_norm := public.normalize_phone(new.phone);
  if length(new.phone_norm) not between 8 and 15 then
    raise exception 'telefono_invalido';
  end if;
  new.updated_at := now();
  return new;
end $$;

drop trigger if exists trg_customers_before_write on public.customers;
create trigger trg_customers_before_write
  before insert or update on public.customers
  for each row execute function public.customers_before_write();

create sequence if not exists public.invoice_number_seq start 1;

create table if not exists public.invoices (
  id                    uuid primary key default gen_random_uuid(),
  invoice_number        text not null unique
                          default ('CD-' || lpad(nextval('public.invoice_number_seq')::text, 6, '0')),
  request_id            uuid unique,   -- evita duplicados si se reintenta la creación
  customer_id           uuid not null references public.customers(id),
  assigned_motorist_id  uuid not null references public.profiles(id),
  delivery_address      text not null check (char_length(btrim(delivery_address)) > 0),
  delivery_fee          numeric(12,2) not null check (delivery_fee >= 0),
  amount_spent          numeric(12,2) check (amount_spent >= 0),
  total                 numeric(12,2) generated always as
                          (case when amount_spent is null then null else amount_spent + delivery_fee end) stored,
  status                text not null default 'pending'
                          check (status in ('pending', 'completed', 'sent', 'cancelled')),
  scheduled_for         timestamptz,
  created_by            uuid not null references public.profiles(id),
  completed_by          uuid references public.profiles(id),
  created_at            timestamptz not null default now(),
  assigned_at           timestamptz not null default now(),
  completed_at          timestamptz,
  sent_at               timestamptz,
  cancelled_at          timestamptz,
  cancel_reason         text,
  updated_at            timestamptz not null default now(),
  constraint invoices_state_consistency check (
       (status = 'pending'  and amount_spent is null and completed_at is null)
    or (status in ('completed', 'sent') and amount_spent is not null and completed_at is not null)
    or (status = 'cancelled')
  )
);
create index if not exists invoices_motorist_status_idx on public.invoices (assigned_motorist_id, status);
create index if not exists invoices_status_created_idx  on public.invoices (status, created_at desc);
create index if not exists invoices_customer_idx        on public.invoices (customer_id);
create index if not exists invoices_created_idx         on public.invoices (created_at desc);
create index if not exists invoices_completed_idx       on public.invoices (completed_at);

drop trigger if exists trg_invoices_touch on public.invoices;
create trigger trg_invoices_touch before update on public.invoices
  for each row execute function public.touch_updated_at();

create table if not exists public.invoice_notifications (
  id            uuid primary key default gen_random_uuid(),
  invoice_id    uuid not null references public.invoices(id) on delete cascade,
  recipient_id  uuid not null references public.profiles(id) on delete cascade,
  type          text not null check (type in ('assigned', 'completed', 'reassigned')),
  message       text not null,
  data          jsonb not null default '{}'::jsonb,
  read_at       timestamptz,
  created_at    timestamptz not null default now()
);
create index if not exists notif_recipient_idx
  on public.invoice_notifications (recipient_id, read_at, created_at desc);

create table if not exists public.invoice_events (
  id          uuid primary key default gen_random_uuid(),
  invoice_id  uuid not null references public.invoices(id) on delete cascade,
  actor_id    uuid references public.profiles(id),
  event_type  text not null,
  details     jsonb not null default '{}'::jsonb,
  created_at  timestamptz not null default now()
);
create index if not exists events_invoice_idx on public.invoice_events (invoice_id, created_at);

create table if not exists public.settings (
  key         text primary key,
  value       jsonb not null,
  updated_at  timestamptz not null default now(),
  updated_by  uuid references public.profiles(id)
);

insert into public.settings (key, value) values
  ('business_name', '"Chepe Delivery"'::jsonb),
  ('default_delivery_fee', '50'::jsonb),
  ('whatsapp_template', to_jsonb(
E'Hola, {cliente}. 👋\nTe compartimos tu factura de {negocio}.\n\n🧾 Factura: {factura}\n📅 Fecha: {fecha}\n🛍️ Monto de tu pedido: C${monto}\n🛵 Costo del delivery: C${delivery}\n💰 TOTAL A PAGAR: C${total}\n\nGracias por preferir {negocio}.'::text))
on conflict (key) do nothing;

-- ---------------------------------------------------------------------
-- 3. ROW LEVEL SECURITY
-- ---------------------------------------------------------------------

alter table public.profiles              enable row level security;
alter table public.customers             enable row level security;
alter table public.invoices              enable row level security;
alter table public.invoice_notifications enable row level security;
alter table public.invoice_events        enable row level security;
alter table public.settings              enable row level security;

-- profiles: cada quien ve el suyo; el admin ve todos. Sin escritura directa
-- (las cuentas se crean/editan solo desde la función de Netlify con service_role).
drop policy if exists profiles_select on public.profiles;
create policy profiles_select on public.profiles for select to authenticated
  using (id = auth.uid() or public.is_admin());

-- customers: el admin gestiona; el motorizado solo ve clientes de sus facturas.
drop policy if exists customers_admin on public.customers;
create policy customers_admin on public.customers for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

drop policy if exists customers_motorist_select on public.customers;
create policy customers_motorist_select on public.customers for select to authenticated
  using (public.is_motorist() and exists (
    select 1 from public.invoices i
    where i.customer_id = customers.id and i.assigned_motorist_id = auth.uid()));

-- invoices: SOLO lectura directa. Toda escritura va por funciones RPC.
drop policy if exists invoices_select on public.invoices;
create policy invoices_select on public.invoices for select to authenticated
  using (public.is_admin() or (assigned_motorist_id = auth.uid() and public.is_motorist()));

-- notificaciones: solo su destinatario (marcar leídas por RPC)
drop policy if exists notif_select on public.invoice_notifications;
create policy notif_select on public.invoice_notifications for select to authenticated
  using (recipient_id = auth.uid() and public.is_active_user());

-- eventos: solo lectura para el admin; nadie los modifica ni borra
drop policy if exists events_select on public.invoice_events;
create policy events_select on public.invoice_events for select to authenticated
  using (public.is_admin());

-- settings: solo admin
drop policy if exists settings_admin on public.settings;
create policy settings_admin on public.settings for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

-- ---------------------------------------------------------------------
-- 4. PRIVILEGIOS DE TABLAS
-- ---------------------------------------------------------------------
revoke all on public.profiles, public.customers, public.invoices,
              public.invoice_notifications, public.invoice_events, public.settings
  from anon, authenticated;
revoke all on sequence public.invoice_number_seq from anon, authenticated;

grant select on public.profiles, public.invoices,
                public.invoice_notifications, public.invoice_events to authenticated;
grant select, insert, update on public.customers to authenticated;
grant select, insert, update on public.settings  to authenticated;

-- ---------------------------------------------------------------------
-- 5. FUNCIONES (RPC) - toda la lógica sensible vive aquí
-- ---------------------------------------------------------------------

create or replace function public.money(n numeric)
returns text language sql immutable as $$
  select to_char(coalesce(n, 0), 'FM999,999,990.00')
$$;

-- ADMIN: crear y asignar factura (idempotente por request_id)
create or replace function public.create_invoice(
  p_request_id     uuid,
  p_customer_name  text,
  p_phone          text,
  p_address        text,
  p_delivery_fee   numeric,
  p_motorist_id    uuid,
  p_scheduled_for  timestamptz default null
) returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  v_inv  public.invoices;
  v_cust uuid;
  v_norm text;
  v_mot  public.profiles;
begin
  if not public.is_admin() then raise exception 'no_autorizado'; end if;

  if p_request_id is not null then
    select * into v_inv from public.invoices where request_id = p_request_id;
    if found then return to_jsonb(v_inv); end if;
  end if;

  if p_customer_name is null or char_length(btrim(p_customer_name)) < 1 then
    raise exception 'cliente_invalido'; end if;
  if p_address is null or char_length(btrim(p_address)) < 1 then
    raise exception 'direccion_invalida'; end if;
  if p_delivery_fee is null or p_delivery_fee < 0 or p_delivery_fee > 99999999 then
    raise exception 'costo_invalido'; end if;
  v_norm := public.normalize_phone(p_phone);
  if length(v_norm) not between 8 and 15 then raise exception 'telefono_invalido'; end if;

  select * into v_mot from public.profiles
   where id = p_motorist_id and role = 'motorizado' and active;
  if not found then raise exception 'motorizado_invalido'; end if;

  insert into public.customers (name, phone, address)
  values (btrim(p_customer_name), btrim(p_phone), nullif(btrim(p_address), ''))
  on conflict (phone_norm) do update
    set name = excluded.name,
        address = coalesce(excluded.address, public.customers.address)
  returning id into v_cust;

  begin
    insert into public.invoices (request_id, customer_id, assigned_motorist_id, delivery_address,
                                 delivery_fee, scheduled_for, created_by)
    values (p_request_id, v_cust, p_motorist_id, btrim(p_address),
            round(p_delivery_fee, 2), p_scheduled_for, auth.uid())
    returning * into v_inv;
  exception when unique_violation then
    select * into v_inv from public.invoices where request_id = p_request_id;
    if found then return to_jsonb(v_inv); end if;
    raise;
  end;

  insert into public.invoice_events (invoice_id, actor_id, event_type, details)
  values (v_inv.id, auth.uid(), 'created',
          jsonb_build_object('delivery_fee', v_inv.delivery_fee, 'motorist_id', p_motorist_id,
                             'motorist', v_mot.full_name));
  insert into public.invoice_events (invoice_id, actor_id, event_type, details)
  values (v_inv.id, auth.uid(), 'assigned',
          jsonb_build_object('motorist_id', p_motorist_id, 'motorist', v_mot.full_name));

  insert into public.invoice_notifications (invoice_id, recipient_id, type, message, data)
  values (v_inv.id, p_motorist_id, 'assigned',
          'Nueva factura asignada: ' || v_inv.invoice_number || ' - ' || btrim(p_customer_name),
          jsonb_build_object('invoice_number', v_inv.invoice_number, 'customer', btrim(p_customer_name)));

  return to_jsonb(v_inv);
end $$;

-- MOTORIZADO: completar factura (única vía para escribir amount_spent)
create or replace function public.complete_invoice(p_invoice_id uuid, p_amount numeric)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  v_inv  public.invoices;
  v_cust public.customers;
  v_me   public.profiles;
begin
  if not public.is_motorist() then raise exception 'no_autorizado'; end if;

  select * into v_inv from public.invoices
   where id = p_invoice_id and assigned_motorist_id = auth.uid() for update;
  if not found then raise exception 'factura_no_encontrada'; end if;
  if v_inv.status <> 'pending' then raise exception 'ya_completada'; end if;
  if p_amount is null or p_amount < 0 or p_amount > 99999999 then
    raise exception 'monto_invalido'; end if;

  update public.invoices
     set amount_spent = round(p_amount, 2), status = 'completed',
         completed_at = now(), completed_by = auth.uid()
   where id = v_inv.id
   returning * into v_inv;

  select * into v_cust from public.customers where id = v_inv.customer_id;
  select * into v_me from public.profiles where id = auth.uid();

  insert into public.invoice_events (invoice_id, actor_id, event_type, details)
  values (v_inv.id, auth.uid(), 'completed',
          jsonb_build_object('amount_spent', v_inv.amount_spent, 'delivery_fee', v_inv.delivery_fee,
                             'total', v_inv.total));

  insert into public.invoice_notifications (invoice_id, recipient_id, type, message, data)
  select v_inv.id, a.id, 'completed',
         'Nueva factura completada' || E'\n' ||
         'Cliente: ' || v_cust.name || E'\n' ||
         'Motorizado: ' || v_me.full_name || E'\n' ||
         'Factura: ' || v_inv.invoice_number || E'\n' ||
         'Monto gastado: C$' || public.money(v_inv.amount_spent) || E'\n' ||
         'Delivery: C$' || public.money(v_inv.delivery_fee) || E'\n' ||
         'Total: C$' || public.money(v_inv.total),
         jsonb_build_object('invoice_number', v_inv.invoice_number, 'customer', v_cust.name,
                            'motorist', v_me.full_name, 'amount_spent', v_inv.amount_spent,
                            'delivery_fee', v_inv.delivery_fee, 'total', v_inv.total,
                            'completed_at', v_inv.completed_at)
    from public.profiles a where a.role = 'admin' and a.active;

  return to_jsonb(v_inv);
end $$;

-- ADMIN: marcar como enviada (solo si está completada)
create or replace function public.mark_invoice_sent(p_invoice_id uuid)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_inv public.invoices;
begin
  if not public.is_admin() then raise exception 'no_autorizado'; end if;
  select * into v_inv from public.invoices where id = p_invoice_id for update;
  if not found then raise exception 'factura_no_encontrada'; end if;
  if v_inv.status = 'sent' then raise exception 'ya_enviada'; end if;
  if v_inv.status <> 'completed' then raise exception 'estado_invalido'; end if;

  update public.invoices set status = 'sent', sent_at = now()
   where id = v_inv.id returning * into v_inv;
  insert into public.invoice_events (invoice_id, actor_id, event_type, details)
  values (v_inv.id, auth.uid(), 'sent', jsonb_build_object('total', v_inv.total));
  return to_jsonb(v_inv);
end $$;

-- ADMIN: reasignar (solo facturas pendientes)
create or replace function public.reassign_invoice(p_invoice_id uuid, p_motorist_id uuid)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_inv public.invoices; v_mot public.profiles; v_old uuid; v_name text;
begin
  if not public.is_admin() then raise exception 'no_autorizado'; end if;
  select * into v_inv from public.invoices where id = p_invoice_id for update;
  if not found then raise exception 'factura_no_encontrada'; end if;
  if v_inv.status <> 'pending' then raise exception 'estado_invalido'; end if;
  select * into v_mot from public.profiles
   where id = p_motorist_id and role = 'motorizado' and active;
  if not found then raise exception 'motorizado_invalido'; end if;
  v_old := v_inv.assigned_motorist_id;
  if v_old = p_motorist_id then return to_jsonb(v_inv); end if;

  update public.invoices set assigned_motorist_id = p_motorist_id, assigned_at = now()
   where id = v_inv.id returning * into v_inv;
  select c.name into v_name from public.customers c where c.id = v_inv.customer_id;

  insert into public.invoice_events (invoice_id, actor_id, event_type, details)
  values (v_inv.id, auth.uid(), 'reassigned',
          jsonb_build_object('from', v_old, 'to', p_motorist_id, 'motorist', v_mot.full_name));
  insert into public.invoice_notifications (invoice_id, recipient_id, type, message, data)
  values (v_inv.id, p_motorist_id, 'reassigned',
          'Se te asignó la factura ' || v_inv.invoice_number || ' - ' || v_name,
          jsonb_build_object('invoice_number', v_inv.invoice_number, 'customer', v_name));
  return to_jsonb(v_inv);
end $$;

-- ADMIN: corregir montos (queda en el historial con motivo)
create or replace function public.admin_update_invoice(
  p_invoice_id uuid, p_delivery_fee numeric, p_amount_spent numeric, p_reason text
) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_inv public.invoices; v_old public.invoices;
begin
  if not public.is_admin() then raise exception 'no_autorizado'; end if;
  if p_reason is null or char_length(btrim(p_reason)) < 3 then raise exception 'motivo_requerido'; end if;
  select * into v_old from public.invoices where id = p_invoice_id for update;
  if not found then raise exception 'factura_no_encontrada'; end if;
  if v_old.status = 'cancelled' then raise exception 'estado_invalido'; end if;
  if p_amount_spent is not null and v_old.status = 'pending' then
    raise exception 'monto_no_permitido'; end if;
  if (p_delivery_fee is not null and (p_delivery_fee < 0 or p_delivery_fee > 99999999))
     or (p_amount_spent is not null and (p_amount_spent < 0 or p_amount_spent > 99999999)) then
    raise exception 'monto_invalido'; end if;

  update public.invoices
     set delivery_fee = coalesce(round(p_delivery_fee, 2), delivery_fee),
         amount_spent = coalesce(round(p_amount_spent, 2), amount_spent)
   where id = v_old.id returning * into v_inv;

  insert into public.invoice_events (invoice_id, actor_id, event_type, details)
  values (v_inv.id, auth.uid(), 'corrected',
          jsonb_build_object('reason', btrim(p_reason),
            'old', jsonb_build_object('delivery_fee', v_old.delivery_fee, 'amount_spent', v_old.amount_spent, 'total', v_old.total),
            'new', jsonb_build_object('delivery_fee', v_inv.delivery_fee, 'amount_spent', v_inv.amount_spent, 'total', v_inv.total)));
  return to_jsonb(v_inv);
end $$;

-- ADMIN: anular (no se borra nada; queda registrado)
create or replace function public.cancel_invoice(p_invoice_id uuid, p_reason text)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_inv public.invoices;
begin
  if not public.is_admin() then raise exception 'no_autorizado'; end if;
  if p_reason is null or char_length(btrim(p_reason)) < 3 then raise exception 'motivo_requerido'; end if;
  select * into v_inv from public.invoices where id = p_invoice_id for update;
  if not found then raise exception 'factura_no_encontrada'; end if;
  if v_inv.status = 'cancelled' then raise exception 'estado_invalido'; end if;
  update public.invoices
     set status = 'cancelled', cancelled_at = now(), cancel_reason = btrim(p_reason)
   where id = v_inv.id returning * into v_inv;
  insert into public.invoice_events (invoice_id, actor_id, event_type, details)
  values (v_inv.id, auth.uid(), 'cancelled', jsonb_build_object('reason', btrim(p_reason)));
  return to_jsonb(v_inv);
end $$;

-- Cualquier usuario activo: marcar sus notificaciones como leídas (null = todas)
create or replace function public.mark_notifications_read(p_ids uuid[] default null)
returns integer
language plpgsql security definer set search_path = public as $$
declare n integer;
begin
  if not public.is_active_user() then raise exception 'no_autorizado'; end if;
  update public.invoice_notifications
     set read_at = now()
   where recipient_id = auth.uid() and read_at is null
     and (p_ids is null or id = any (p_ids));
  get diagnostics n = row_count;
  return n;
end $$;

-- ADMIN: estadísticas. p_period: 'day' | 'week' | 'month' (zona Managua)
create or replace function public.dashboard_stats(p_period text default 'day')
returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare
  v_local timestamp := now() at time zone 'America/Managua';
  v_start timestamptz;
  r jsonb;
begin
  if not public.is_admin() then raise exception 'no_autorizado'; end if;
  v_start := (case p_period
                when 'week'  then date_trunc('week',  v_local)
                when 'month' then date_trunc('month', v_local)
                else              date_trunc('day',   v_local) end) at time zone 'America/Managua';
  select jsonb_build_object(
    'period', coalesce(p_period, 'day'),
    'since', v_start,
    'delivery_income', coalesce((select sum(delivery_fee) from invoices
                          where status in ('completed','sent') and completed_at >= v_start), 0),
    'gross_total', coalesce((select sum(total) from invoices
                          where status in ('completed','sent') and completed_at >= v_start), 0),
    'invoices_in_period', (select count(*) from invoices
                          where status <> 'cancelled' and created_at >= v_start),
    'pending',   (select count(*) from invoices where status = 'pending'),
    'awaiting_send', (select count(*) from invoices where status = 'completed'),
    'sent',      (select count(*) from invoices where status = 'sent' and sent_at >= v_start),
    'customers', (select count(*) from customers),
    'active_motorists', (select count(*) from profiles where role = 'motorizado' and active)
  ) into r;
  return r;
end $$;

-- ADMIN: listado de motorizados con conteos
create or replace function public.motorists_summary()
returns jsonb
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'no_autorizado'; end if;
  return coalesce((
    select jsonb_agg(jsonb_build_object(
      'id', p.id, 'full_name', p.full_name, 'username', p.username, 'active', p.active,
      'created_at', p.created_at,
      'pending',   (select count(*) from invoices i where i.assigned_motorist_id = p.id and i.status = 'pending'),
      'completed', (select count(*) from invoices i where i.assigned_motorist_id = p.id and i.status in ('completed','sent'))
    ) order by p.active desc, p.full_name)
    from profiles p where p.role = 'motorizado'), '[]'::jsonb);
end $$;

-- ADMIN: historial con filtros y paginación
create or replace function public.search_invoices(
  p_q text default null, p_status text default null, p_motorist uuid default null,
  p_from date default null, p_to date default null,
  p_limit int default 25, p_offset int default 0
) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare
  v_q text := nullif(btrim(coalesce(p_q, '')), '');
  v_digits text := regexp_replace(coalesce(p_q, ''), '\D', '', 'g');
  v_lim int := least(greatest(coalesce(p_limit, 25), 1), 100);
  v_off int := greatest(coalesce(p_offset, 0), 0);
  v_total bigint; v_rows jsonb;
begin
  if not public.is_admin() then raise exception 'no_autorizado'; end if;
  select coalesce(jsonb_agg(to_jsonb(x) - 'cnt' order by x.created_at desc), '[]'::jsonb),
         coalesce(max(x.cnt), 0)
    into v_rows, v_total
  from (
    select i.id, i.invoice_number, i.status, i.delivery_fee, i.amount_spent, i.total,
           i.created_at, i.completed_at, i.sent_at, i.delivery_address, i.assigned_motorist_id,
           c.name as customer_name, c.phone as customer_phone,
           m.full_name as motorist_name,
           count(*) over () as cnt
      from invoices i
      join customers c on c.id = i.customer_id
      join profiles m on m.id = i.assigned_motorist_id
     where (v_q is null
            or i.invoice_number ilike '%' || v_q || '%'
            or c.name ilike '%' || v_q || '%'
            or (v_digits <> '' and c.phone_norm like '%' || v_digits || '%'))
       and (p_status is null or i.status = p_status)
       and (p_motorist is null or i.assigned_motorist_id = p_motorist)
       and (p_from is null or (i.created_at at time zone 'America/Managua')::date >= p_from)
       and (p_to   is null or (i.created_at at time zone 'America/Managua')::date <= p_to)
     order by i.created_at desc
     limit v_lim offset v_off
  ) x;
  return jsonb_build_object('total', v_total, 'rows', v_rows);
end $$;

-- ADMIN: detalle de una factura + eventos
create or replace function public.get_invoice_detail(p_invoice_id uuid)
returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare v jsonb; ev jsonb;
begin
  if not public.is_admin() then raise exception 'no_autorizado'; end if;
  select to_jsonb(i) || jsonb_build_object(
           'customer_name', c.name, 'customer_phone', c.phone,
           'motorist_name', m.full_name, 'completed_by_name', cb.full_name,
           'created_by_name', ab.full_name)
    into v
    from invoices i
    join customers c on c.id = i.customer_id
    join profiles m on m.id = i.assigned_motorist_id
    left join profiles cb on cb.id = i.completed_by
    left join profiles ab on ab.id = i.created_by
   where i.id = p_invoice_id;
  if v is null then raise exception 'factura_no_encontrada'; end if;
  select coalesce(jsonb_agg(jsonb_build_object(
           'id', e.id, 'event_type', e.event_type, 'details', e.details,
           'created_at', e.created_at, 'actor', p.full_name) order by e.created_at), '[]'::jsonb)
    into ev
    from invoice_events e left join profiles p on p.id = e.actor_id
   where e.invoice_id = p_invoice_id;
  return jsonb_build_object('invoice', v, 'events', ev);
end $$;

-- ---------------------------------------------------------------------
-- 6. PERMISOS DE EJECUCIÓN (solo usuarios autenticados; nunca anon)
-- ---------------------------------------------------------------------
do $$
declare r record;
begin
  for r in
    select p.oid::regprocedure as sig
      from pg_proc p join pg_namespace n on n.oid = p.pronamespace
     where n.nspname = 'public' and p.prokind = 'f'
       and p.proname = any (array[
         'is_admin','is_motorist','is_active_user','normalize_phone','money',
         'create_invoice','complete_invoice','mark_invoice_sent','reassign_invoice',
         'admin_update_invoice','cancel_invoice','mark_notifications_read',
         'dashboard_stats','motorists_summary','search_invoices','get_invoice_detail'])
  loop
    execute format('revoke all on function %s from public, anon', r.sig);
    execute format('grant execute on function %s to authenticated', r.sig);
  end loop;
end $$;

-- ---------------------------------------------------------------------
-- 7. REALTIME (solo las tablas necesarias, para ahorrar recursos)
-- ---------------------------------------------------------------------
do $$
begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime') then
    begin
      alter publication supabase_realtime add table public.invoices;
    exception when duplicate_object then null; end;
    begin
      alter publication supabase_realtime add table public.invoice_notifications;
    exception when duplicate_object then null; end;
  end if;
end $$;

-- FIN DEL ESQUEMA
