-- =====================================================================
-- CHEPE DELIVERY - Crear el perfil del PRIMER ADMINISTRADOR
-- =====================================================================
-- PASOS PREVIOS (en el panel de Supabase):
--   1. Authentication > Users > "Add user" > "Create new user"
--   2. Email:      admin@chepedelivery.app   (usuario "admin" + @chepedelivery.app)
--      Password:   una contraseña larga y privada
--      Marca "Auto Confirm User".
--   3. Luego ejecuta este script en SQL Editor.
--
-- Si quieres otro nombre de usuario, cambia 'admin' en las dos líneas marcadas
-- (el correo debe ser <usuario>@chepedelivery.app).
-- =====================================================================

insert into public.profiles (id, full_name, username, role, active)
select id, 'Administrador', 'admin', 'admin', true           -- <- nombre y usuario
  from auth.users
 where email = 'admin@chepedelivery.app'                      -- <- correo creado
on conflict (id) do update set role = 'admin', active = true;

-- Verificación: debe devolver 1 fila con role = admin
select id, username, role, active from public.profiles where role = 'admin';
