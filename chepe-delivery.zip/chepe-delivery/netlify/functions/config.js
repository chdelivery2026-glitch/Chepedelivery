// Entrega al navegador SOLO los valores públicos de Supabase.
// La clave "anon" es pública por diseño (la seguridad la dan las políticas RLS).
// NUNCA devuelvas aquí la service_role.
exports.handler = async () => {
  const url = process.env.SUPABASE_URL;
  const anon = process.env.SUPABASE_ANON_KEY;
  if (!url || !anon) {
    return {
      statusCode: 500,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ error: 'Faltan SUPABASE_URL o SUPABASE_ANON_KEY en Netlify.' }),
    };
  }
  return {
    statusCode: 200,
    headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
    body: JSON.stringify({
      supabaseUrl: url,
      supabaseAnonKey: anon,
      emailDomain: process.env.AUTH_EMAIL_DOMAIN || 'chepedelivery.app',
    }),
  };
};
