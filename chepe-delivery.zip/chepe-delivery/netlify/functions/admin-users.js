// Gestión segura de cuentas de motorizados (usa la clave service_role, solo en el servidor).
// Acciones: create | update | set_active | reset_password
// Solo puede invocarla un administrador activo (se valida el token de sesión Y el perfil en la BD).
const { createClient } = require('@supabase/supabase-js');

const DOMAIN = () => process.env.AUTH_EMAIL_DOMAIN || 'chepedelivery.app';
const USERNAME_RE = /^[a-z0-9._-]{3,30}$/;

const json = (statusCode, obj) => ({
  statusCode,
  headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
  body: JSON.stringify(obj),
});

function validPassword(p) {
  return typeof p === 'string' && p.length >= 8 && p.length <= 72;
}
function validName(n) {
  return typeof n === 'string' && n.trim().length >= 2 && n.trim().length <= 100;
}

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return json(405, { error: 'Método no permitido' });

  const url = process.env.SUPABASE_URL;
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !serviceKey) return json(500, { error: 'Servidor sin configurar (faltan variables de entorno).' });

  const admin = createClient(url, serviceKey, { auth: { autoRefreshToken: false, persistSession: false } });

  // 1) Identificar al que llama a partir de su token de sesión
  const auth = event.headers.authorization || event.headers.Authorization || '';
  const token = auth.startsWith('Bearer ') ? auth.slice(7) : '';
  if (!token) return json(401, { error: 'Sesión no válida.' });
  const { data: u, error: uerr } = await admin.auth.getUser(token);
  if (uerr || !u || !u.user) return json(401, { error: 'Sesión no válida.' });

  // 2) Verificar en la base de datos que es administrador activo
  const { data: me } = await admin.from('profiles').select('role, active').eq('id', u.user.id).maybeSingle();
  if (!me || me.role !== 'admin' || !me.active) return json(403, { error: 'No autorizado.' });

  let body;
  try { body = JSON.parse(event.body || '{}'); } catch { return json(400, { error: 'Solicitud inválida.' }); }
  const { action } = body;

  // Solo se pueden gestionar cuentas con rol motorizado
  async function getMotorist(id) {
    if (typeof id !== 'string') return null;
    const { data } = await admin.from('profiles').select('*').eq('id', id).eq('role', 'motorizado').maybeSingle();
    return data;
  }

  try {
    if (action === 'create') {
      const username = String(body.username || '').trim().toLowerCase();
      const full_name = String(body.full_name || '').trim();
      const password = body.password;
      if (!USERNAME_RE.test(username)) return json(400, { error: 'Usuario inválido: 3-30 caracteres, solo letras minúsculas, números, punto, guion y guion bajo.' });
      if (!validName(full_name)) return json(400, { error: 'Escribe el nombre completo (2 a 100 caracteres).' });
      if (!validPassword(password)) return json(400, { error: 'La contraseña debe tener entre 8 y 72 caracteres.' });

      const { data: dup } = await admin.from('profiles').select('id').ilike('username', username).maybeSingle();
      if (dup) return json(409, { error: 'Ese nombre de usuario ya existe.' });

      const email = `${username}@${DOMAIN()}`;
      const { data: created, error: cerr } = await admin.auth.admin.createUser({
        email, password, email_confirm: true, user_metadata: { full_name },
      });
      if (cerr || !created || !created.user) {
        return json(400, { error: 'No se pudo crear la cuenta: ' + (cerr ? cerr.message : 'error desconocido') });
      }
      const { error: perr } = await admin.from('profiles').insert({
        id: created.user.id, full_name, username, role: 'motorizado', active: true,
      });
      if (perr) {
        await admin.auth.admin.deleteUser(created.user.id); // deshacer para no dejar cuentas huérfanas
        return json(500, { error: 'No se pudo crear el perfil: ' + perr.message });
      }
      return json(200, { ok: true, id: created.user.id });
    }

    if (action === 'update') {
      const m = await getMotorist(body.id);
      if (!m) return json(404, { error: 'Motorizado no encontrado.' });
      const patch = {};
      if (body.full_name !== undefined) {
        if (!validName(body.full_name)) return json(400, { error: 'Nombre inválido.' });
        patch.full_name = String(body.full_name).trim();
      }
      if (body.username !== undefined) {
        const username = String(body.username).trim().toLowerCase();
        if (!USERNAME_RE.test(username)) return json(400, { error: 'Usuario inválido.' });
        if (username !== m.username) {
          const { data: dup } = await admin.from('profiles').select('id').ilike('username', username).neq('id', m.id).maybeSingle();
          if (dup) return json(409, { error: 'Ese nombre de usuario ya existe.' });
          const { error: eerr } = await admin.auth.admin.updateUserById(m.id, { email: `${username}@${DOMAIN()}`, email_confirm: true });
          if (eerr) return json(400, { error: 'No se pudo cambiar el usuario: ' + eerr.message });
          patch.username = username;
        }
      }
      if (Object.keys(patch).length) {
        const { error: perr } = await admin.from('profiles').update(patch).eq('id', m.id);
        if (perr) return json(500, { error: perr.message });
      }
      return json(200, { ok: true });
    }

    if (action === 'set_active') {
      const m = await getMotorist(body.id);
      if (!m) return json(404, { error: 'Motorizado no encontrado.' });
      const active = body.active === true;
      const { error: perr } = await admin.from('profiles').update({ active }).eq('id', m.id);
      if (perr) return json(500, { error: perr.message });
      // Bloquea/desbloquea también el inicio de sesión en Supabase Auth
      const { error: berr } = await admin.auth.admin.updateUserById(m.id, { ban_duration: active ? 'none' : '876000h' });
      if (berr) return json(500, { error: 'Perfil actualizado, pero no se pudo bloquear la sesión: ' + berr.message });
      return json(200, { ok: true });
    }

    if (action === 'reset_password') {
      const m = await getMotorist(body.id);
      if (!m) return json(404, { error: 'Motorizado no encontrado.' });
      if (!validPassword(body.password)) return json(400, { error: 'La contraseña debe tener entre 8 y 72 caracteres.' });
      const { error: perr } = await admin.auth.admin.updateUserById(m.id, { password: body.password });
      if (perr) return json(400, { error: 'No se pudo restablecer: ' + perr.message });
      return json(200, { ok: true });
    }

    return json(400, { error: 'Acción desconocida.' });
  } catch (e) {
    return json(500, { error: 'Error interno del servidor.' });
  }
};
